# Online Reports Gateway

[![Quality Gate Status](https://sonarqube.dev.icpapps.preprod.govt.nz/api/project_badges/measure?project=onlinereports-gateway&metric=alert_status)](https://sonarqube.dev.icpapps.preprod.govt.nz/dashboard?id=onlinereports-gateway)

This gateway microservice offers an api to send reports from public facing applications, currently only a PEGA based 105 report from the police website, and have them added to the OnDuty Reports queue in eQuip.

This service is deployed in ICP in the mobility-<env> namespace.


## Technology Stack

* JDK 11 (AdoptOpenJDK - see the Dockerfile for authoritative versioning)
* Spring Framework / Spring Boot - nzp-spring-boot mvn parent.
* Docker Engine
* Kubernetes - IBM Cloud Private variant in production
* Helm

## API Details

### Authentication

This service is authenticated via keycloak, the client is called onlinereports-gateway.

Since there is no 'natural' user making this call the incoming openid-connect JWT will be a service account based on the client.  
This is obtained by datapower and supplied as the standard 'Authorization: Bearer' token on the call to this service.

As this service has an embedded mobility-services and is accessing the mobility database directly we use a service account
to represent to user that would normally be logged in to eQuip or OnDuty.  This is the same user the trigger processor
authenticates as during Post Processing, e.g. SVCWTPP.  This service account exists in AD and as a NIA user in the NIA database.

Testing the service directly from the command line using curl will require you to supply the bearer token, you can use the 
generate token script from the helm-dev repo to create this, e.g.

```
source $HELM-DEV/bin/gen_kc_token.sh onlinereports-gateway && curl -v -H "Content-Type: application/json" -H "Authorization: Bearer $JWT_TOKEN" -d @105-schema/src/test/resources/valid_message-uuid-adjusted.json "http://localhost:8080/api/report"
```

### Online Report

* API - /api/report - Send a Report to the gateway to be persisted into the mobility database.
* JSON - see schema? 
* Http method - POST
* Success - 200 response
* Failure - 400 reponse 

### Testing

To run the integration tests you'll need to add the ICP preprod certs to your JVM.  They can be found at src/test/resources/st-icpapps-preprod-govt-nz-chain.pem
On a Mac, you can use a command like the one below (obviously substituting the correct path to your JVM's cacerts file)

sudo keytool -import -noprompt -trustcacerts -alias ST-ICP -file st-icpapps-preprod-govt-nz-chain.pem -keystore /Library/Java/JavaVirtualMachines/jdk-11.0.3.jdk/Contents/Home/lib/security/cacerts -storepass changeit


## TODO
* monitoring; prometheus, grafana?
