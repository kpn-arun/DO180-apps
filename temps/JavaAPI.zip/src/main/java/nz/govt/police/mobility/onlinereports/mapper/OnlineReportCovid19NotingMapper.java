package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.TIME_FORMAT;
import static nz.govt.police.service.NiaObjectConstants.CV_SCENE_STATION_NOT_SPECIFIED;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.onlinereports.services.Covid19AlertService;
import nz.govt.police.mobility.service.om.Narrative;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportCreateService;
import nz.govt.police.service.NiaObjectConstants;
import nz.govt.police.service.nia.om.NiaUser;

/**
 * 
 * @author yhpw09
 *
 */
@Service
public class OnlineReportCovid19NotingMapper {

    public static final String COVID_19_ALERT_REFERENCE = "Op COVID";
    public static final String COVID_19_ALERT_DESCRIPTION = "CONFIRMED CASE OF COVID-19 IN NZ";
    
    // TODO create following constants in snapshot version of ApplicationConstants 
    public static final int RECORD_SUB_CATEGORY_OTHER_INFORMATON = 1015;
    public static final int ASSIGNMENT_STATION_PNHQ = 431;
    public static final int REPORTING_CHANNEL_EMAIL = 7;
    public static final int RELIABILITY_COMPLETE = 1;

    @Inject
    OnlineReportCreateService createService;

    @Inject
    OnlineReportCodedValueMapper codedValueMapper;

    public Noting mapNoting(Report report) throws OnlineReportException {

        Noting noting = createService.createNotingWithDefaults();

        noting.setStartDate(NDateUtil.dateFromString(report.getStartDate(), DATE_FORMAT));
        noting.setStartTime(NDateUtil.timeFromString(report.getStartTime(), TIME_FORMAT));
        noting.setExternalReference(report.getReportId());
        noting.setNarrative(new Narrative(report.getNarrative()));
        noting.setReference(COVID_19_ALERT_REFERENCE);
        noting.setSubject("#" + COVID_19_ALERT_DESCRIPTION);
        noting.setDescription(COVID_19_ALERT_DESCRIPTION);
        noting.setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);
        noting.setCreationTimestamp(NDateUtil.timestampNow());
        noting.setNotingCategory(NiaObjectConstants.CV_RECORD_TYPE_NOTING); // intelligence
        noting.setNotingType(new NCodedValue(CodeTableConstants.CT_RECORD_SUB_CATEGORY, RECORD_SUB_CATEGORY_OTHER_INFORMATON)); // other information
        noting.setReportingStation(new NCodedValue(CodeTableConstants.CT_ASSIGNMENT_STATION, ASSIGNMENT_STATION_PNHQ)); // PNHQ
        noting.setReportingChannel(new NCodedValue(CodeTableConstants.CT_REPORTING_CHANNEL, REPORTING_CHANNEL_EMAIL)); // email
        noting.setSourceReliability(new NCodedValue(CodeTableConstants.CT_SOURCE_RELIABILITY, RELIABILITY_COMPLETE)); // COMPLETELY RELIABLE
        noting.setInformationReliability(new NCodedValue(CodeTableConstants.CT_SOURCE_RELIABILITY, RELIABILITY_COMPLETE)); // COMPLETELY RELIABLE
        noting.setFmcPriority(codedValueMapper.mapCodedValue(report.getPriority(), true));
        noting.setLocationProximity(codedValueMapper.mapCodedValue(report.getProximity(), true));

        return noting;
    }

}
