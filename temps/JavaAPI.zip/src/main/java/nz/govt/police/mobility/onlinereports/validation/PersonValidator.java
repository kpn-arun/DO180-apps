package nz.govt.police.mobility.onlinereports.validation;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.Email;
import nz.govt.police.mobility.onlinereports.om.Name;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Phone;

@Component
public class PersonValidator extends AbstractValidator implements NiaObjectValidator {

    @Override
    public void validate(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        Person person = (Person) niaObject;

        UUID niaObjectUuid = niaObject.getUuid();

        validateBasic(niaObject, onlineReportErrors);

        // Licence
        String dlicno = StringUtils.trim(person.getDlicno());
        if (StringUtils.isNotEmpty(dlicno) && !Pattern.matches(VALID_DLICNO_REGEX, dlicno)) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.dlicno", dlicno);
        }

        // Emails
        validateEmails(person.getEmails(), onlineReportErrors, niaObjectUuid);

        // Phones
        validatePhones(person.getPhones(), onlineReportErrors, niaObjectUuid);
    }
    
    @Override
    public void validateBasic(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        Person person = (Person) niaObject;
        UUID niaObjectUuid = niaObject.getUuid();
        
        // validate names
        validateCurrentName(person.getCurrentName(), onlineReportErrors, niaObjectUuid);
        validateName(person.getPreviousName(), onlineReportErrors, niaObjectUuid);

        // validate dob
        String birthDate = person.getBirthDate();
        if (validateDate(birthDate) == null) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.birthDate", birthDate);
        }

        // validate address
        UUID address = person.getAddress();
        if (address == null) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.address");
        }

        // Address type
        validateCodeMandatory(niaObjectUuid, onlineReportErrors, "niaObject.addressType", AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, person.getAddressType(),
                CodeTableConstants.CT_PERSON_ADDRESS_CODES);

        // Gender
        validateCodeMandatory(niaObjectUuid, onlineReportErrors, "niaObject.gender", AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, person.getGender(),
                CodeTableConstants.CT_GENDER);
    }

    private void validateCurrentName(Name name, OnlineReportErrors onlineReportErrors, UUID niaObjectUuid) {
        if (name == null) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.currentName");
            return;
        }

        validateName(name, onlineReportErrors, niaObjectUuid);
    }

    private void validateName(Name name, OnlineReportErrors onlineReportErrors, UUID niaObjectUuid) {
        if (name == null) {
            return; // valid for previous name
        }

        // Mandatory
        String firstName = StringUtils.trim(name.getFirstName());
        if (StringUtils.isBlank(firstName) || StringUtils.length(firstName) > NiaObjectValidator.PERSON_FIRST_NAME_MAX_LENGTH) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "firstName", firstName);
        }

        // Mandatory
        String familyName = StringUtils.trim(name.getFamilyName());
        if (StringUtils.isBlank(familyName) || StringUtils.length(familyName) > NiaObjectValidator.PERSON_FAMILY_NAME_MAX_LENGTH) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "familyName", familyName);
        }

        // Optional
        String middleNames = StringUtils.trim(name.getMiddleNames());
        if (StringUtils.isNotBlank(middleNames) && StringUtils.length(middleNames) > NiaObjectValidator.PERSON_MIDDLE_NAMES_MAX_LENGTH) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "middleNames", middleNames);
        }
    }

    private void validateEmails(List<Email> emails, OnlineReportErrors onlineReportErrors, UUID niaObjectUuid) {
        if (CollectionUtils.isEmpty(emails)) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.emails");
            return;
        }

        if (emails.stream().filter(Email::isPrimary).count() != 1) {
            onlineReportErrors.addError(niaObjectUuid, "person must have exactly one primary email", "niaObject.emails");
        }

        int index = 0;
        for (Email email : emails) {
            String emailAddress = StringUtils.trim(email.getEmailAddress());
            if (StringUtils.isBlank(emailAddress) || StringUtils.length(emailAddress) > NiaObjectValidator.PERSON_EMAIL_MAX_LENGTH) {
                onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, String.format("niaObject.email[%s]", index++ ), emailAddress);
            }
        }
    }

    private void validatePhones(List<Phone> phones, OnlineReportErrors onlineReportErrors, UUID niaObjectUuid) {
        if (CollectionUtils.isEmpty(phones)) {
            onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.phones");
            return;
        }

        if (phones.stream().filter(Phone::isPrimary).count() != 1) {
            onlineReportErrors.addError(niaObjectUuid, "person must have exactly one primary phone", "niaObject.phones");
        }

        int index = 0;
        for (Phone phone : phones) {

            // Mandatory
            validateCodeMandatory(niaObjectUuid, onlineReportErrors, String.format("niaObject.phones[%s].type", index), AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE,
                    phone.getType(), CodeTableConstants.CT_PERSON_TELEPHONE_CODES);

            // Mandatory
            validateCodeMandatory(niaObjectUuid, onlineReportErrors, String.format("niaObject.phones[%s].countryCode", index), AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE,
                    phone.getCountryCode(), CodeTableConstants.CT_TELEPHONE_COUNTRY_CODE);

            // Optional
            String areaCode = StringUtils.trim(phone.getAreaCode());
            if (StringUtils.isNotEmpty(areaCode)
                    && (!NumberUtils.isDigits(areaCode) || StringUtils.length(phone.getAreaCode()) > NiaObjectValidator.PHONE_AREA_CODE_MAX_LENGTH)) {
                onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, String.format("niaObject.phones[%s].areaCode", index ), areaCode);
            }

            // Mandatory
            String number = StringUtils.trim(phone.getNumber());
            if (StringUtils.isBlank(number) || !NumberUtils.isDigits(number) || StringUtils.length(number) > NiaObjectValidator.PHONE_NUMBER_MAX_LENGTH) {
                onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, String.format("niaObject.phones[%s].number", index ), number);
            }

            index++;
        }
    }
}
