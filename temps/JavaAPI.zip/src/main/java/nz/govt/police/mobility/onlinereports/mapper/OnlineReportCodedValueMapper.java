package nz.govt.police.mobility.onlinereports.mapper;

import org.springframework.stereotype.Service;

import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.mobility.onlinereports.om.CodedValue;

@Service
public class OnlineReportCodedValueMapper {

    public ICodedValue mapCodedValue(CodedValue codeValue, boolean isNullable) {

        if (isNullable && (codeValue == null || codeValue.getCodeValue() == null || codeValue.getCodeTableId() == null)) {
            return null;
        }

        return new NCodedValue(codeValue.getCodeTableId().longValue(), codeValue.getCodeValue());
    }
}
