package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * @author shce24
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
public class Location extends NiaObject {
	private Long niaLocationId;
	private String unitNumber;
	private CodedValue unitType;
	private String streetNumber;
	private String streetName;
	private CodedValue streetType;
	private CodedValue streetDirection;
	private String town;
	private String province;
	private CodedValue suburbTown;
	private CodedValue country;
	private double latitude;
	private double longitude;
	private String locationDetail;
}
