package nz.govt.police.mobility.onlinereports.om;

import java.util.List;

import lombok.Data;

/**
 * The top level object received from PEGA
 * 
 * @author shce24
 *
 */
@Data
public class OnlineReport {
    
    private List<NiaObject> niaObjects;
    private Attachment originalPdf;
    private List<Attachment> attachments;
    private Report report;

}
