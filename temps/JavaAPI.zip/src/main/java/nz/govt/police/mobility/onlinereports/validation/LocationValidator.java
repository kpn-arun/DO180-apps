package nz.govt.police.mobility.onlinereports.validation;

import java.util.UUID;

import org.springframework.stereotype.Component;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;

@Component
public class LocationValidator extends AbstractValidator implements NiaObjectValidator {	
	
	@Override
    public void validate(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        Location location = (Location) niaObject;

        if (location.getNiaLocationId() != null) {
            // no need to go further
            return;
        }

        UUID niaObjectUuid = location.getUuid();

        if (location.getSuburbTown() == null && location.getCountry() == null && location.getLocationDetail() == null) {
            if (location.getSuburbTown() == null && location.getCountry() == null) {
                onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE,
                        location.getSuburbTown() == null ? "niaobject.country" : "niaobject.suburbTown");
            } else {
                onlineReportErrors.addError(niaObjectUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaobject.locationDetail");
                return;
            }
        }

        validateCode(niaObjectUuid, onlineReportErrors, "niaobject.suburbTown", location.getSuburbTown(), CodeTableConstants.CT_TOWN_SUBURB);

        validateCode(niaObjectUuid, onlineReportErrors, "niaobject.country", location.getCountry(), CodeTableConstants.CT_PLACE_OF_BIRTH_COUNTRY);

        validateCode(niaObjectUuid, onlineReportErrors, "niaobject.unitType", location.getUnitType(), CodeTableConstants.CT_LOCN_UNIT_TYPE);

        validateCode(niaObjectUuid, onlineReportErrors, "niaobject.streetType", location.getStreetType(), CodeTableConstants.CT_LOCN_STREET_TYPE);

        validateCode(niaObjectUuid, onlineReportErrors, "niaobject.streetDirection", location.getStreetDirection(), CodeTableConstants.CT_LOCN_AIW_ST_DIR_SUFF);
    }    
}
