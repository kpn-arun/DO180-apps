package nz.govt.police.mobility.onlinereports.om;

import java.util.UUID;

import lombok.Data;

/**
 * The analogue of our Mobility Field Report object, as received from PEGA
 * 
 * @author shce24
 *
 */
@Data
public class Report {

    private UUID reportUuid;
    private String narrative;
    private UUID location;
    private String reportId;
    
    private String startDate;
    private String startTime;
    
    private String endDate;
    private String endTime;
    
    private String reportedDate;
    private String reportedTime;
    
    private CodedValue priority;
    private CodedValue proximity;
    
}
