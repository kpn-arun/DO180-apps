package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Email {
    
    private String emailAddress;
    private boolean primary;

}
