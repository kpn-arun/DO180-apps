package nz.govt.police.mobility.onlinereports.om;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiErrors {

    private int status;
    private String message;
    private List<ApiError> errors;   
}
