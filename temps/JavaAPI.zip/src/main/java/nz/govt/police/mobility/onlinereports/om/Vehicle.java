package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * @author yhpw09
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
public class Vehicle extends NiaObject {
	private String vehicleRegNo;
	
	// Code table 107
	private CodedValue type;
	
	// Code table 105
	private CodedValue make;
	
	private String identifyingFeatures;
}
