package nz.govt.police.mobility.onlinereports;

public class OnlineReportException extends Exception {
    private static final long serialVersionUID = 1L;

    private final OnlineReportErrors errors;

    public OnlineReportException(String message) {
        super(message);
        errors = null;
    }

    public OnlineReportException(String message, Exception e) {
        super(message, e);
        errors = null;
    }

    public OnlineReportException(String message, OnlineReportErrors errors) {
        super(message);
        this.errors = errors;
    }

    public OnlineReportErrors getErrors() {
        return errors;
    }
}
