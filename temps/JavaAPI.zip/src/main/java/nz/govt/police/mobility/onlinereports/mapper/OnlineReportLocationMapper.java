package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.NIA.Common.ApplicationConstants.LOCATION_CAT_FOREIGN;
import static nz.govt.police.NIA.Common.ApplicationConstants.LOCATION_CAT_FULL;
import static nz.govt.police.NIA.Common.ApplicationConstants.LOCATION_CAT_NFA_PARTIAL_UNKNOWN_OTHER;
import static nz.govt.police.NIA.Common.CodeTableConstants.CT_SCENE_STATION;
import static nz.govt.police.service.NiaObjectConstants.CV_LOCATION;
import static nz.govt.police.service.NiaObjectConstants.CV_SCENE_STATION_NOT_SPECIFIED;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.BaseLocationService;
import nz.govt.police.mobility.service.onduty.util.NiaObjectUtils;
import nz.govt.police.nia.location.service.client.ILocationServiceClient;
import nz.govt.police.service.ObjectNotFoundException;
import nz.govt.police.service.entities.nia.location.Location;

/**
 * Code for mapping PEGA Locations to ActivityLocations lives here
 * Note that right now we've not got Jackson to map the JSON into the PEGA Location object - the fields are just sitting on NiaObject for now
 * 
 * @author shce24
 *
 */
@Service
@CommonsLog
public class OnlineReportLocationMapper {

    @Autowired
    @Qualifier(value = "baseLocationService")
    BaseLocationService locationService;
    
    @Inject 
    ILocationServiceClient locationServiceClient;
  
    @Autowired
	private OnlineReportsApplicationConfiguration applicationConfiguration;

    @Autowired 
    OnlineReportCodedValueMapper codedValueMapper;
    
    public ActivityLocation mapRecordLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation, Noting noting) throws OnlineReportException {
        
        if (onlineReportLocation.getNiaLocationId() != null) {
            log.debug("Finding NIA location");
            try {
                ActivityLocation activityLocation = locationService.addQueriedLocationToNotingAsRecordLocation(onlineReportLocation.getNiaLocationId(), noting);

                // always copy the scene station off the record location onto the noting
                ICodedValue sceneStation = activityLocation.getLocation().getSceneStation();
                if (sceneStation != null) {
                    noting.setSceneStation(sceneStation);
                }

                return activityLocation;
            } catch (ObjectNotFoundException e) {
                throw new OnlineReportException("Location not found in NIA with ID: " + onlineReportLocation.getNiaLocationId(), e);
            }
        }
        
        else {
        	Location location = setupNewLocation(onlineReportLocation);
        	
            if (getLocationCategory(onlineReportLocation) == LOCATION_CAT_FOREIGN) {
                // set Outside New Zealand (Area)
                noting.setSceneStation(new NCodedValue(CT_SCENE_STATION, 1585));
            }
        	
        	return locationService.addNewLocationAsRecordLocation(location, noting);
        }
        
    }
    
    public ActivityLocation mapLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation, Noting noting) throws OnlineReportException {

        if (onlineReportLocation.getNiaLocationId() != null) {
            log.debug("Finding NIA location");
            try {
                return locationService.addQueriedObjectToRecord(onlineReportLocation.getNiaLocationId(), CV_LOCATION, noting);
            } catch (ObjectNotFoundException e) {
                throw new OnlineReportException("Location not found in NIA with ID: " + onlineReportLocation.getNiaLocationId(), e);
            }
        }

        else {
            Location location = setupNewLocation(onlineReportLocation);
            return locationService.addNewLocationToNoting(location, noting);
        }
    }
    
    /**
     * Package private for unit testing
     * 
     * @param onlineReportLocation
     * @param noting
     * @return
     * @throws OnlineReportException
     */
    Location setupNewLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) throws OnlineReportException {
        switch (getLocationCategory(onlineReportLocation)) {
        case LOCATION_CAT_FULL:
            return createFullNiaLocation(onlineReportLocation);
        case LOCATION_CAT_NFA_PARTIAL_UNKNOWN_OTHER:
            return createPartialNiaLocation(onlineReportLocation);
        case LOCATION_CAT_FOREIGN:
            return createForeignLocation(onlineReportLocation);
        default:
            throw new OnlineReportException("Cannot create an unknown location");
        }
    }
    
    private Location createFullNiaLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) {
        log.debug("Creating new NZ location");
        Location location = NiaObjectUtils.createNewNiaLocation(LOCATION_CAT_FULL);

        setCommonFields(location, onlineReportLocation);

        // only for NZ locations
        location.setTownSuburb(codedValueMapper.mapCodedValue(onlineReportLocation.getSuburbTown(), false));

        Location formattedLocation = locationServiceClient.formatLocation(applicationConfiguration.getLocationServiceUrl(), location);
        location.setLocationDetail(formattedLocation.getLocationDetail());

        // Defaulted when null
        ICodedValue formattedUnitType = formattedLocation.getUnitType();
        if (formattedUnitType != null && location.getUnitType() == null) {
            location.setUnitType(formattedUnitType);
        }

        location.setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);

        return location;
    }

    private Location createPartialNiaLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) {
        String locationDetail = onlineReportLocation.getLocationDetail();
        log.debug("Using location detail." + locationDetail);

        Location location = NiaObjectUtils.createNewNiaLocation(LOCATION_CAT_NFA_PARTIAL_UNKNOWN_OTHER);
        location.setLocationDetail(locationDetail);

        location.setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);

        return location;
    }

    private Location createForeignLocation(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) {
        log.debug("Creating new foreign location");
        Location location = NiaObjectUtils.createNewNiaLocation(LOCATION_CAT_FOREIGN);

        setCommonFields(location, onlineReportLocation);

        // only for foreign locations
        location.setTown(onlineReportLocation.getTown());
        location.setCountry(codedValueMapper.mapCodedValue(onlineReportLocation.getCountry(), false));

        Location formattedLocation = locationServiceClient.formatLocation(applicationConfiguration.getLocationServiceUrl(), location);
        location.setLocationDetail(formattedLocation.getLocationDetail());

        return location;
    }

    private void setCommonFields(Location location, nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) {
        location.setUnitNo(onlineReportLocation.getUnitNumber());
        location.setUnitType(codedValueMapper.mapCodedValue(onlineReportLocation.getUnitType(), true));
        location.setStreetNumber(onlineReportLocation.getStreetNumber());
        location.setStreetName(onlineReportLocation.getStreetName());
        location.setStreetType(codedValueMapper.mapCodedValue(onlineReportLocation.getStreetType(), true));
        location.setStreetDirection(codedValueMapper.mapCodedValue(onlineReportLocation.getStreetDirection(), true));
    }

    private int getLocationCategory(nz.govt.police.mobility.onlinereports.om.Location onlineReportLocation) {
        if (onlineReportLocation.getSuburbTown() != null) {
            return LOCATION_CAT_FULL;
        }

        if (onlineReportLocation.getLocationDetail() != null) {
            return LOCATION_CAT_NFA_PARTIAL_UNKNOWN_OTHER;
        }

        return LOCATION_CAT_FOREIGN;
    }

}
