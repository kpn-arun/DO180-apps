package nz.govt.police.mobility.onlinereports.context;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import nz.govt.police.NIA.Common.ApplicationConstants;
import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.mobility.service.UserContext;
import nz.govt.police.service.nia.om.INiaUser;

@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class OnlineReportsGatewayRequest implements UserContext {

	@Setter
	private String userId;
		
	@Setter
	private String deviceType;
	
	private Long requestId;

	public String getUserId() {
		return userId;
	}
	
	public String getUnit() {
		return "Not Impl";
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.toUpperCase();
	}

	@Override
	public String getDeviceId() {
		return this.userId + deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	
	public Long getRequestId() {
        return requestId;
    }
	
	public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

	@Override
	public ICodedValue getStation() {
		return null;
	}

	@Override
	public ICodedValue getReportingStation() {
		return null;
	}

	@Override
	public boolean isUserInRole(String... roles) {
		return true; 		
	}
	@Override
	public INiaUser getSupervisor() {
		return null;
	}
	
	@Override
	public ICodedValue getMobilityApplication() {
		return new NCodedValue(CodeTableConstants.CT_MOBILITY_APPLICATION, ApplicationConstants.MOBILITY_APPLICATION_ON_DUTY);
	}

    @Override
    public boolean clientSupportsYouthPso() {
        return false;
    }

    @Override
    public boolean isPibUser() {
        return false;
    }
	
}
