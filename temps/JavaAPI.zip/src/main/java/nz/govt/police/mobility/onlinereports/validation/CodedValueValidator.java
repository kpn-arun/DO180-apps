package nz.govt.police.mobility.onlinereports.validation;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.service.impl.CodeTableService;

@Component
@CommonsLog
public class CodedValueValidator {

	@Inject
	CodeTableService codeTableService;
	
	public boolean isCodeTableValid(CodedValue codeValue, long codeTableId) {
		return isCodeTableValid(codeValue, codeTableId, false);
	}

	public boolean isCodeTableValid(CodedValue codeValue, long codeTableId, boolean isMandatory) {
		try {
			validate(codeValue, codeTableId, isMandatory);
		} catch (OnlineReportException ex) {
			log.error(ex.getMessage());
			return false;
		}

		return true;
	}

	// Validate incoming coded value against expected codeTableId
	private void validate(CodedValue codeValue, long codeTableId, boolean isMandatory) throws OnlineReportException {

		if (isMandatory && codeValue == null) {
			throw new OnlineReportException("No CodedValue supplied for codeTableId:" + codeTableId);
		}

		if (codeValue == null) {
			return;
		}

		if (codeValue.getCodeTableId() == null || codeValue.getCodeTableId().longValue() != codeTableId) {
			throw new OnlineReportException(
					"Request does not contain CodedValue.codeTableId for codeTableId:" + codeTableId);
		}

		if (codeValue.getCodeValue() == null) {
			throw new OnlineReportException(
					"Request does not contain a CodedValue.codeValue for codeTableId:" + codeTableId);
		}

		NCodedValue code = new NCodedValue(codeTableId, codeValue.getCodeValue());
		if (codeTableService.getCode(code) == null) {
			throw new OnlineReportException("Unknown coded value supplied for code table: " + codeTableId
					+ " - value was: " + codeValue.getCodeValue());
		}
	}
}
