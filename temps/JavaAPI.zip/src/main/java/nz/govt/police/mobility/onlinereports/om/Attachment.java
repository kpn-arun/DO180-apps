package nz.govt.police.mobility.onlinereports.om;

import java.util.UUID;

import lombok.Data;

/**
 * An attachment as received from the PEGA interface
 * 
 * @author shce24
 *
 */
@Data
public class Attachment {
    
    private UUID attachmentUuid;
    private byte[] data;
    private String contentType;
    private String description;
    private String filename;

}
