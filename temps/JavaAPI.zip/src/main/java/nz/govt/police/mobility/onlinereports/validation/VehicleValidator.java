package nz.govt.police.mobility.onlinereports.validation;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.Vehicle;

@Component
public class VehicleValidator extends AbstractValidator implements NiaObjectValidator {

    @Override
    public void validate(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        Vehicle vehicle = (Vehicle) niaObject;

        if (StringUtils.isBlank(vehicle.getVehicleRegNo()) || StringUtils.length(vehicle.getVehicleRegNo()) > NiaObjectValidator.VEHICLE_REG_NO_MAX_LENGTH) {
            onlineReportErrors.addError(vehicle.getUuid(), AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.vehicleRgNo", vehicle.getVehicleRegNo());
        }
        
        UUID uuid = vehicle.getUuid();

        validateCodeMandatory(uuid, onlineReportErrors, "niaObject.type", AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, vehicle.getType(), CodeTableConstants.CT_VEHICLE_CATEGORY_TYPE_STYLE);

        validateCode(uuid, onlineReportErrors, "niaObject.make", vehicle.getMake(), CodeTableConstants.CT_VEHICLE_MAKE);
        
        String identifyingFeatures = vehicle.getIdentifyingFeatures();
        if(StringUtils.isNotBlank(identifyingFeatures) && StringUtils.length(identifyingFeatures) > NiaObjectValidator.IDENTIFYING_FEATURES_MAX_LENGTH) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.identifyingFeatures", identifyingFeatures);
        }
    }
}
