package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A coded value as received from the PEGA interface
 * 
 * @author shce24
 *
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CodedValue {
    
    private Long codeTableId;
    private Long codeValue;
    private String codeDescription;
    
    @Override
    public String toString() {
        return "[codeTableId:" + codeTableId + ",codeValue:" + codeValue + "]";
    }
}
