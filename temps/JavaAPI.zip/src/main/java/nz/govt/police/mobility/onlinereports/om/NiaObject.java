package nz.govt.police.mobility.onlinereports.om;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A NIA object as received from the PEGA interface
 * 
 * Abstract class for all object types
 * 
 * @author shce24
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class NiaObject {
	private UUID uuid;
	private CodedValue objectType;
}
