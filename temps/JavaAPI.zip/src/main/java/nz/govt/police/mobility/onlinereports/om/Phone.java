package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Phone {
    
    private CodedValue type;
    private CodedValue countryCode;
    private String number;
    private String areaCode;
    private boolean primary;

}
