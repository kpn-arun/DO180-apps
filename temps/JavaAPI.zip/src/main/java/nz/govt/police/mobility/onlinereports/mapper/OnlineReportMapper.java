package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.TIME_FORMAT;
import static nz.govt.police.service.NiaObjectConstants.CV_SCENE_STATION_NOT_SPECIFIED;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.om.FieldReport;
import nz.govt.police.mobility.service.om.Narrative;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportCreateService;

/**
 * Code for mapping fields on the PEGA Report to our Mobility FieldReport
 * 
 * @author shce24
 *
 */
@Service
public class OnlineReportMapper {
    
    @Inject
    OnlineReportCreateService createService;
    
    @Inject
    OnlineReportCodedValueMapper codedValueMapper;
    
    public FieldReport mapReport(Report report) throws OnlineReportException {
        
        FieldReport fieldReport = createService.createNewOnlineReport();

        fieldReport.setStartDate(NDateUtil.dateFromString(report.getStartDate(), DATE_FORMAT));
        fieldReport.setStartTime(NDateUtil.timeFromString(report.getStartTime(), TIME_FORMAT));
        fieldReport.setEndDate(NDateUtil.dateFromString(report.getEndDate(), DATE_FORMAT));
        fieldReport.setEndTime(NDateUtil.timeFromString(report.getEndTime(), TIME_FORMAT));
        fieldReport.setReportedDate(NDateUtil.dateFromString(report.getReportedDate(), DATE_FORMAT));
        fieldReport.setReportedTime(NDateUtil.timeFromString(report.getReportedTime(), TIME_FORMAT));
        fieldReport.setExternalReference(report.getReportId());
        fieldReport.setNarrative(new Narrative(report.getNarrative()));        
        fieldReport.setFmcPriority(codedValueMapper.mapCodedValue(report.getPriority(), false));
        fieldReport.setLocationProximity(codedValueMapper.mapCodedValue(report.getProximity(), false));
        fieldReport.setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);// defaulted
        
        return fieldReport;        
    }
}
