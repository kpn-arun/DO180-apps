package nz.govt.police.mobility.onlinereports;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import nz.govt.police.mobility.onlinereports.om.ApiError;
import nz.govt.police.mobility.onlinereports.om.ApiErrors;

public class OnlineReportErrors {

    private List<OnlineReportError> onlineReportErrors = new ArrayList<>();

    private class OnlineReportError {
        private UUID uuid;
        private String message;
        private String field;
        private String originalValue;
    }

    public void addError(UUID uuid, String message, String field, String originalValue) {
        OnlineReportError onlineReportError = new OnlineReportError();
        onlineReportError.uuid = uuid;
        onlineReportError.message = message;
        onlineReportError.field = field;
        onlineReportError.originalValue = originalValue;
        addError(onlineReportError);
    }

    public void addError(UUID uuid, String message, String field) {
        OnlineReportError onlineReportError = new OnlineReportError();
        onlineReportError.uuid = uuid;
        onlineReportError.message = message;
        onlineReportError.field = field;
        addError(onlineReportError);
    }

    public void addError(OnlineReportError message) {
        this.onlineReportErrors.add(message);
    }

    public boolean hasErrors() {
        return !onlineReportErrors.isEmpty();
    }

    public int count() {
        return onlineReportErrors.size();
    }

    public List<ApiError> toApiErrors() {
        List<ApiError> apiErrors = new ArrayList<>();
        for (OnlineReportError onlineReportError : onlineReportErrors) {
            apiErrors.add(ApiError.builder().uuid(onlineReportError.uuid != null ? onlineReportError.uuid.toString() : null).field(onlineReportError.field)
                    .message(onlineReportError.message).originalValue(onlineReportError.originalValue).build());
        }

        return apiErrors;
    }
}
