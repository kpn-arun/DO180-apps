package nz.govt.police.mobility.onlinereports.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.interfaces.ITimestamp;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Report;

/**
 * The root of all validations Ideally, this should be moved to spring custom hierarchical validations at controller level. Gave it a quick go but didn't work
 * well. Given more time I would definitely go that way.
 * 
 * @author yhpw09
 *
 */
@Component
public class Covid19Validation extends AbstractValidation {

    @Autowired
    NiaObjectValidator personValidator;

    @Autowired
    NiaObjectValidator locationValidator;

    @Autowired
    ReportValidator reportValidator;

    public void validate(OnlineReport onlineReport) throws OnlineReportException {

        OnlineReportErrors onlineReportErrors = new OnlineReportErrors();

        Report report = onlineReport.getReport();

        if (report == null) {
            onlineReportErrors.addError(null, "Missing value", "report");
        } else {
            reportValidator.validateBasic(report, onlineReportErrors);
        }

        if (!CollectionUtils.isEmpty(onlineReport.getNiaObjects())) {
            validateNiaObjects(onlineReport, onlineReportErrors);
            
            if (onlineReport.getNiaObjects().stream().filter(niaObject -> niaObject instanceof Location).count() > 1) {
                onlineReportErrors.addError(null, "A maximum of 1 location is allowed", "NiaObject.locations");
            }

            if (onlineReport.getNiaObjects().stream().filter(niaObject -> niaObject instanceof Person).count() > 1) {
                onlineReportErrors.addError(null, "A maximum of 1 person is allowed", "NiaObject.person");
            }
        }

        if (onlineReportErrors.hasErrors()) {
            throw new OnlineReportException("Validation Errors", onlineReportErrors);
        }
    }

    protected void validateNiaObject(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        if (niaObject instanceof Location) {
            locationValidator.validate(niaObject, onlineReportErrors);
        } else {
            personValidator.validateBasic(niaObject, onlineReportErrors);
        }
    }
}