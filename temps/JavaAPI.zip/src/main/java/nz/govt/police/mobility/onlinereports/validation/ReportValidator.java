package nz.govt.police.mobility.onlinereports.validation;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.interfaces.ITimestamp;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.utils.DateTimeUtils;

@Component
public class ReportValidator extends AbstractValidator {

    public void validate(Report report, OnlineReportErrors onlineReportErrors) {

        UUID uuid = report.getReportUuid();

        validateDateTime(report, onlineReportErrors);

        if (StringUtils.isBlank(report.getReportId())) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.reportedId");
        }

        if (StringUtils.isBlank(report.getNarrative())) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.narrative");
        }

        if (report.getLocation() == null) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.recordLocation");
        }

        validateCodeMandatory(uuid, onlineReportErrors, "report.priority", AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, report.getPriority(), CodeTableConstants.CT_FMC_PRIORITY);

        validateCodeMandatory(uuid, onlineReportErrors, "report.proximity", AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, report.getProximity(),
                CodeTableConstants.CT_LCTN_PROXIMITY_TYPE);
    }
    
    public void validateBasic(Report report, OnlineReportErrors onlineReportErrors) {
        UUID uuid = report.getReportUuid();

        validateDateTime(report, onlineReportErrors, false);

        if (StringUtils.isBlank(report.getNarrative())) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.narrative");
        }
    }
    
    private void validateDateTime(Report report, OnlineReportErrors onlineReportErrors) {
        validateDateTime(report, onlineReportErrors, true);
    }
    
    private void validateDateTime(Report report, OnlineReportErrors onlineReportErrors, boolean fullValidation) {
        UUID uuid = report.getReportUuid();

        // required field
        String startDateString = report.getStartDate();
        IDate startDate = validateDate(startDateString);
        if (startDate == null) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startDate", startDateString);
        }

        // required field
        String startTimeString = report.getStartTime();
        ITime startTime = validateTime(startTimeString);
        if (startTime == null) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startTime", startTimeString);
        }

        // The Start Date must not be in the future.
        ITimestamp startTS = getTS(startDate, startTime);
        if (startTS != null && startTS.after(NDateUtil.now())) {
            onlineReportErrors.addError(uuid, ERROR_MESSAGE_DATE_IN_FUTURE, "report.startDate, report.startTime");
        }

        // if start Date is 100 years prior to todays date throw an error (to catch typos - we want to allow entering of historical occurrences)
        if (startDate != null && startDate.before(NDateUtil.subtractYears(NDateUtil.dateNow(), 100))) {
            onlineReportErrors.addError(uuid, "Date 100 years prior", "report.startDate");
        }       
        
        if(!fullValidation) {
            return;
        }

        // Check conditionally required fields: endDate is required if endTime is specified, and vice versa.
        IDate endDate = validateDate(report.getEndDate());
        ITime endTime = validateTime(report.getEndTime());
        if ((endDate == null && endTime != null) || (endDate != null && endTime == null)) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.endDate, report.endTime");
        }
        
        // The End Date must not be in the future.
        ITimestamp endTS = getTS(endDate, endTime);
        if (endTS != null && endTS.after(NDateUtil.now())) {
            onlineReportErrors.addError(uuid, ERROR_MESSAGE_DATE_IN_FUTURE, "report.endDate, report.endTime");
        }

        // The End Date must not be before the Start Date.
        if (endDate != null && endTime != null) {
            endTS = NDateUtil.tsFromNDateAndNTime(endDate, endTime);
            startTS = getTS(startDate, startTime);
            if (startTS != null && endTS != null && endTS.before(startTS)) {
                onlineReportErrors.addError(uuid, "Report end date/time must not be before report start date/time",
                        "report.startDate, report.startTime, report.endDate, report.endTime");
            }
        }

        // daylight savings check
        if (DateTimeUtils.isDaylightSavingsTime(endDate, endTime)) {
            onlineReportErrors.addError(uuid, "Date is in daylight savings range", "report.endDate, report.endTime");
        }

        // required field
        String reportedDateString = report.getReportedDate();
        IDate reportedDate = validateDate(reportedDateString);
        if (reportedDate == null) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedDate", reportedDateString);
        }

        // required field
        String reportedTimeString = report.getReportedTime();
        ITime reportedTime = validateTime(report.getReportedTime());
        if (reportedTime == null) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedTime", reportedTimeString);
        }

        // The Reported Date must not be in the future.
        ITimestamp reportedTS = getTS(reportedDate, reportedTime);
        if (reportedTS != null && reportedTS.after(NDateUtil.now())) {
            onlineReportErrors.addError(uuid, ERROR_MESSAGE_DATE_IN_FUTURE, "report.reportedDate, report.reportedTime");
        }

        // The Reported Date must be after the Start Date.
        if (startDate != null && startTime != null && reportedDate != null && reportedTime != null) {
            ITimestamp startTimestamp = NDateUtil.tsFromNDateAndNTime(startDate, startTime);
            ITimestamp reportedTimestamp = NDateUtil.tsFromNDateAndNTime(reportedDate, reportedTime);
            if (reportedTimestamp.beforeTimestamp(startTimestamp)) {
                onlineReportErrors.addError(uuid, "Report reported date/time must not be before report start date/time",
                        "report.startDate, report.startTime, report.reportedDate, report.reportedTime");
            }
        }

        // daylight savings check
        if (DateTimeUtils.isDaylightSavingsTime(reportedDate, reportedTime)) {
            onlineReportErrors.addError(uuid, "Date is in daylight savings range", "report.reportedDate, report.reportedTime");
        }
    }        
}
