package nz.govt.police.mobility.onlinereports.deserializer;

import java.io.IOException;

import org.springframework.boot.json.JsonParseException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.utils.NUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Vehicle;
import nz.govt.police.service.NiaObjectConstants;

/**
 * Custom deserializer. Will resolve to one of the subclasses of NiaObject.
 * 
 * @author yhpw09
 *
 */
public class NiaObjectJsonDeserializer extends JsonDeserializer<NiaObject> {

	private static final String JSON_NODE_FIELD_NAME_FOR_CODE_VALUE = "codeValue";

	@Override
	public NiaObject deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
		ObjectMapper mapper = (ObjectMapper) jp.getCodec();

		ObjectNode obj = mapper.readTree(jp);

		ICodedValue objectTypeCode = extractObjectTypeFromJson(obj);

		if (NiaObjectConstants.CV_PERSON.equals(objectTypeCode)) {
			return mapper.treeToValue(obj, Person.class);
		}

		if (NiaObjectConstants.CV_VEHICLE.equals(objectTypeCode)) {
			return mapper.treeToValue(obj, Vehicle.class);
		}

		if (NiaObjectConstants.CV_LOCATION.equals(objectTypeCode)) {
			return mapper.treeToValue(obj, Location.class);
		}

		throw new JsonParseException(new OnlineReportException("Field NiaObject.objectType ("
				+ NUtil.stringFromCodedValue(objectTypeCode) + ") has an invalid value"));
	}

	private ICodedValue extractObjectTypeFromJson(ObjectNode niaObjectJsonNode) {
		JsonNode objectTypeNode = niaObjectJsonNode.get("objectType");
		if (objectTypeNode == null) {
			throw new JsonParseException(new OnlineReportException(
					"Empty value for field NiaObject.objectType in incoming JSON." + niaObjectJsonNode.toString()));
		}

		JsonNode codeValueNode = objectTypeNode.get(JSON_NODE_FIELD_NAME_FOR_CODE_VALUE);
		if (codeValueNode != null) {
			return new NCodedValue(CodeTableConstants.CT_OBJECT_TYPE, codeValueNode.toString());
		}

		throw new JsonParseException(
				new OnlineReportException("Field NiaObject.objectType (" + objectTypeNode + ") has an invalid value"));
	}
}