package nz.govt.police.mobility.onlinereports.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nz.govt.police.common.datatypes.NAlertCode;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.service.exception.StaleUpdateException;
import nz.govt.police.mobility.service.impl.InformationAlertService;
import nz.govt.police.mobility.service.om.ActivityInformationAlert;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.ActivityObject;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.service.nia.om.InformationAlert;

@Service("OnlineReportInformationAlertMapper")
public class OnlineReportInformationAlertMapper {
    
    public static final String NARRATIVE_PERSON = "NOT FOR BROADCAST\n" + "This person tested positive for Coronavirus (COVID-19) on Date.\n"
            + "If an emergency response is required involving this person, responding staff should adhere to the infection prevention measures for COVID-19. Refer to the 'CheckPoint App: Health, Safety and Wellness COVID-19 Coronavirus' for further information.\n"
            + "\n"
            + "If possible contact your DCC before attending. Consider alternative options for non-urgent matters and use cell phone for any transmissions of Comms.";

    public static final String NARRATIVE_LOCATION = "NOT FOR BROADCAST\n"
            + "This address is linked to a confirmed case of Coronavirus (COVID-19).  Use cell phone for any transmissions of comms. Should an emergency response be required at this address, responding staff should adhere to the infection prevention measures for COVID-19.  Contact your DCC before attending this address. Consider alternative options for non-urgent matters related to this address.";

    public static final int EXPIRY_3_MONTHS = 3;

    // TODO Move to Application Constants
    public static final long INFORMATION_ALERT_CATEGORY_LOCATION = 267;
    public static final long INFORMATION_ALERT_CATEGORY_PERSON = 265;

    @Autowired
    InformationAlertService informationAlertService;

    public ActivityInformationAlert mapInformationAlert(Noting noting, ActivityObject activityObject) throws OnlineReportException {
        ActivityInformationAlert activityInfoAlert = map(noting, activityObject);
        save(activityInfoAlert);
        return activityInfoAlert;
    }

    private ActivityInformationAlert map(Noting noting, ActivityObject activityObject) throws OnlineReportException {

        InformationAlert covidAlert = new InformationAlert();
        covidAlert.setNarrative((activityObject instanceof ActivityLocation) ? NARRATIVE_LOCATION : NARRATIVE_PERSON);
        covidAlert.setCategory(
                new NAlertCode((activityObject instanceof ActivityLocation) ? INFORMATION_ALERT_CATEGORY_LOCATION : INFORMATION_ALERT_CATEGORY_PERSON));
        covidAlert.setStartDate(noting.getStartDate());
        covidAlert.setStartTime(noting.getStartTime());
        covidAlert.setExpiryDate(NDateUtil.addMonths(noting.getStartDate(), EXPIRY_3_MONTHS));
        covidAlert.setExpiryTime(noting.getStartTime());

        ActivityInformationAlert activityInfoAlert = new ActivityInformationAlert();
        activityInfoAlert.setInformationAlert(covidAlert);
        activityInfoAlert.setNotingUuid(noting.getActivityObjectUuid());
        activityInfoAlert.setActivityObjectId(noting.getActivityObjectId());
        activityInfoAlert.setActivityId(noting.getActivityId());
        activityInfoAlert.setTargetActivityObjectUuid(activityObject.getActivityObjectUuid());

        return activityInfoAlert;
    }

    private void save(ActivityInformationAlert activityInfoAlert) throws OnlineReportException {
        try {
            informationAlertService.insert(activityInfoAlert);
        } catch (StaleUpdateException ex) {
            // TODO FIX
            throw new OnlineReportException(ex.getMessage());
        }
    }

}
