package nz.govt.police.mobility.onlinereports.controller;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsGatewayRequest;
import nz.govt.police.mobility.onlinereports.om.ApiErrors;
import nz.govt.police.mobility.onlinereports.om.ApiResponse;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.services.Covid19AlertService;
import nz.govt.police.mobility.onlinereports.services.OnlineReportService;

@CommonsLog
@RequestMapping(path = "/api")
@RestController
public class OnlineReportsController {
    
    public static final String COVID_19_SERVLET_PATH = "/covid19";

	@Autowired
    OnlineReportService onlineReportService;
	
	@Autowired
    Covid19AlertService covid19AlertService;
	
	@Autowired
    OnlineReportsApplicationConfiguration applicationConfiguration;
    
    @PostMapping(path= "/report", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> addReport(@RequestBody OnlineReport report) {
        
        try {
            long startTime = System.currentTimeMillis();
            UUID fieldReportUuid = onlineReportService.createReport(report);
            log.info("Report " + report.getReport().getReportUuid() + " successfully processed in " + (System.currentTimeMillis() - startTime) + " ms.");
            return ResponseEntity.ok().body(ApiResponse.builder().policeReportUuid(fieldReportUuid).reportUuid(report.getReport().getReportUuid()).status(HttpStatus.OK.value()).build());
        } 
        
        // these will be errors with the input data which we've detected and returned a specific exception message to say what's wrong
        catch (Exception e) {
            return handleException(report, e);
        }
    }
    
    @PostMapping(path = COVID_19_SERVLET_PATH, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> addCovid19Alert(@RequestBody OnlineReport report) {
        
        try {
            long startTime = System.currentTimeMillis();
            UUID fieldReportUuid = covid19AlertService.createCovid19Alert(report);
            log.info("Covid 19 alert " + report.getReport().getReportUuid() + " successfully processed in " + (System.currentTimeMillis() - startTime) + " ms.");
            return ResponseEntity.ok().body(ApiResponse.builder().policeReportUuid(fieldReportUuid).reportUuid(report.getReport().getReportUuid()).status(HttpStatus.OK.value()).build());
        } 
        
        // these will be errors with the input data which we've detected and returned a specific exception message to say what's wrong
        catch (Exception e) {
            return handleException(report, e);
        }
    }
    
    private ResponseEntity<Object> handleException(OnlineReport report, Exception ex) {
    	if(ex instanceof OnlineReportException) {
    		OnlineReportException e = (OnlineReportException) ex;
    		log.error("Error with data supplied for report ID: " + (report.getReport() != null ? report.getReport().getReportId() : null) 
                    + " and UUID: " + (report.getReport() != null ? report.getReport().getReportUuid() : null), e);
            
            final ApiErrors apiErrors;
            if (e.getErrors() != null) {
                apiErrors = ApiErrors.builder().status(BAD_REQUEST.value()).message("Bad Request").errors(e.getErrors().toApiErrors()).build();
            } else {
                apiErrors = ApiErrors.builder().status(BAD_REQUEST.value()).message(e.getMessage()).build();
            }

            return ResponseEntity.status(BAD_REQUEST).body(apiErrors);
    	} 
    	
    	// Generic Exception
    	// catch any random exceptions so they're not picked up by the default spring exception handler, which will output the full stacktrace in the response body
        // we only want to output a simple message to PEGA, not the full stacktrace as we don't want it to leak outside of Police
    	log.error("Error creating field report for report ID: " + report.getReport().getReportId()
                + " and UUID: " + report.getReport().getReportUuid(), ex);
        return ResponseEntity.status(INTERNAL_SERVER_ERROR).body(ApiErrors.builder().status(INTERNAL_SERVER_ERROR.value()).build());
    }
    
    // this picks up on malformed JSON and logs to our error log what the problem was
    // unfortunately the body returned to PEGA doesn't include the exception message saying where the JSON was malformed
    @ExceptionHandler
    @ResponseStatus(BAD_REQUEST)
    public ResponseEntity<Object> handle(HttpMessageNotReadableException e) {
        log.error("Returning HTTP 400 Bad Request.", e);
        return ResponseEntity.status(BAD_REQUEST).body(ApiErrors.builder().status(BAD_REQUEST.value()).message("JSON parse failure - syntax error. Check your JSON and object type codes are valid and look at the system logs for the cause.").build());
    }
}