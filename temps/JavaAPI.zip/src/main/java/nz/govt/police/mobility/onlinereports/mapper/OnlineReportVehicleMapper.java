package nz.govt.police.mobility.onlinereports.mapper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.service.om.ActivityVehicle;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.noting.NotingVehicleService;
import nz.govt.police.mobility.service.onduty.util.NiaObjectUtils;
import nz.govt.police.mobility.service.util.IdFactory;
import nz.govt.police.mobility.service.utils.ActivityObjectUtils;
import nz.govt.police.mobility.service.utils.EquipVehicleSchemaUtils;
import nz.govt.police.service.nia.om.NiaVehicle;
import nz.govt.police.service.nia.om.OnlineReportInvolvedVehicle;
import nz.govt.police.service.nia.om.Vehicle;

/**
 * Mapper to map PEGA Json to ActivityVehicle
 * 
 * @author yhpw09
 *
 */
@Service
@CommonsLog
public class OnlineReportVehicleMapper {

    @Autowired
    NotingVehicleService notingVehicleService;

    public void mapVehicle(nz.govt.police.mobility.onlinereports.om.Vehicle onlineReportVehcile, Noting noting) throws OnlineReportException {
        log.debug("Create ActivityVehicle from Online Report Form and add it to Nia Noting. Noting Id:" + noting.getNotingId());

        NiaVehicle niaVehicle = EquipVehicleSchemaUtils.newVehicle();
        niaVehicle.setRegNo(StringUtils.trim(onlineReportVehcile.getVehicleRegNo().toUpperCase()));
        niaVehicle.setType(new NCodedValue(onlineReportVehcile.getType().getCodeTableId(), onlineReportVehcile.getType().getCodeValue().intValue()));

        if (onlineReportVehcile.getMake() != null) {
            niaVehicle.setMake(new NCodedValue(onlineReportVehcile.getMake().getCodeTableId(), onlineReportVehcile.getMake().getCodeValue().intValue()));
        }

        Vehicle vehicle = new Vehicle();
        vehicle.setNiaVehicle(niaVehicle);

        ActivityVehicle activityVehicle = NiaObjectUtils.niaVehicleToActivityVehicle(noting, vehicle, false);

        // Create involved object always
        OnlineReportInvolvedVehicle onlineReportInvolvedVehicle = new OnlineReportInvolvedVehicle();
        onlineReportInvolvedVehicle.setIdentifyingFeatures(StringUtils.trim(onlineReportVehcile.getIdentifyingFeatures()));
        onlineReportInvolvedVehicle.setActivityObjectUuid(IdFactory.getRandomUUID());
        onlineReportInvolvedVehicle.setInvolvedVehicleUuid(activityVehicle.getActivityObjectUuid());
        ActivityObjectUtils.createActivityInvolvedObject(noting, activityVehicle, onlineReportInvolvedVehicle);
        activityVehicle.setOnlineReportInvolvedVehicle(onlineReportInvolvedVehicle);

        notingVehicleService.addNewVehicleToNoting(activityVehicle, noting);
    }
}