package nz.govt.police.mobility.onlinereports.services;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportAttachmentMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportLocationMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportPersonMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportVehicleMapper;
import nz.govt.police.mobility.onlinereports.om.Attachment;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Vehicle;
import nz.govt.police.mobility.onlinereports.validation.Validation;
import nz.govt.police.mobility.service.Enums.WorkflowAction;
import nz.govt.police.mobility.service.MobilityServicesConstants;
import nz.govt.police.mobility.service.exception.StaleUpdateException;
import nz.govt.police.mobility.service.impl.AttachmentService;
import nz.govt.police.mobility.service.impl.OutboundTriggerService;
import nz.govt.police.mobility.service.impl.reportextract.ReportingExtractService;
import nz.govt.police.mobility.service.interfaces.IWorkflowService;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.FieldReport;
import nz.govt.police.mobility.service.om.Holder;
import nz.govt.police.mobility.service.om.PostProcessingData;
import nz.govt.police.mobility.service.onduty.impl.BaseLocationService;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportOffenceService;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportSaveService;
import nz.govt.police.service.NiaObjectConstants;
import nz.govt.police.service.ServiceException;

@CommonsLog
@Service
public class OnlineReportService extends AbstractReportService {
    
    @Autowired
    OnlineReportSaveService onlineReportsSaveService;
    
    @Autowired
    AttachmentService attachmentService;
    
    @Autowired
    OnlineReportAttachmentMapper attachmentMapper;

    @Autowired
    OnlineReportLocationMapper locationMapper;
    
    @Autowired
    OnlineReportVehicleMapper vehicleMapper;
    
    @Autowired
    OnlineReportPersonMapper personMapper;
    
    @Autowired
    OnlineReportMapper reportMapper;
    
    @Autowired
    @Qualifier(value = "baseLocationService")
    private BaseLocationService locationService;
    
    @Autowired
    OutboundTriggerService outboundTriggerService;
    
    @Autowired
    OnlineReportOffenceService offenceService;
    
    @Autowired
    IWorkflowService workflowService;
    
    @Autowired
    Validation validation;
    
    @Autowired
    ReportingExtractService reportingExtractService;
    
    public UUID createReport(OnlineReport report) throws ServiceException, OnlineReportException {
        
        if (report.getReport() == null) {
            throw new OnlineReportException("No report data found.");
        }
        
        // validations
        log.info("Running validations: " + report.getReport().getReportUuid());        
        validation.validate(report);
        
        log.info("Processing report: " + report.getReport().getReportUuid());

        FieldReport fieldReport = reportMapper.mapReport(report.getReport());
        
        // Nia Objects        
        Map<String, List<NiaObject>> niaObjects = getNiaObjects(report);
        
        // Record location. Guaranteed to be 1 by validation above
        locationMapper.mapRecordLocation((Location) niaObjects.get(RECORD_LOCATION_KEY).get(0), fieldReport);
        
        // 105 Offence
        offenceService.addOnlineReportOffenceToFieldReport(fieldReport);
        
        // Note we only set the workflow status to accepted after we've added the objects we need to it
        // This is because if you add new objects to an accepted document they get marked as not needing a requery - and we want FMC to requery any new objects that come from PEGA
        onlineReportsSaveService.saveNewLocally(fieldReport);
        
        FieldReport previous = SerializationUtils.clone(fieldReport);

        // Add Vehicles
        for (NiaObject niaObject : niaObjects.get(VEHICLE_KEY)) {
            vehicleMapper.mapVehicle((Vehicle) niaObject, fieldReport);
        }

        // Add address
        Map<UUID, ActivityLocation> originalUuidToActivityLocationMap = new HashMap<>();
        for (NiaObject niaObject : niaObjects.get(LOCATION_KEY)) {
            ActivityLocation activityLocation = locationMapper.mapLocation((Location) niaObject, fieldReport);
            originalUuidToActivityLocationMap.put(niaObject.getUuid(), activityLocation);
        }

		// Add Persons
        for (NiaObject niaObject : niaObjects.get(PERSON_KEY)) {
            personMapper.mapPerson((Person) niaObject, fieldReport, originalUuidToActivityLocationMap);
        }

		onlineReportsSaveService.saveInMobility(new Holder<FieldReport>(fieldReport, previous));

        try {
            workflowService.changeWorkflowStatus(fieldReport, WorkflowAction.SUBMIT, "", null, false);
            workflowService.changeWorkflowStatus(fieldReport, WorkflowAction.ACCEPT, "", null, false);
        } catch (StaleUpdateException e) {
            throw new ServiceException(e);
        }
        
        if (report.getOriginalPdf() == null) {
            throw new OnlineReportException("No original report PDF found in report: " + report.getReport().getReportUuid());
        }
        attachmentService.insertAttachmentInMobility(attachmentMapper.mapPdf(report.getOriginalPdf(), fieldReport.getActivityId(), fieldReport.getActivityObjectId(), report.getReport().getReportId()));
        
        for (Attachment attachment : Optional.ofNullable(report.getAttachments()).orElseGet(Collections::emptyList)) {
            attachmentService.insertAttachmentInMobility(attachmentMapper.mapAttachment(attachment, fieldReport.getActivityId(), fieldReport.getActivityObjectId()));
        }
  
        PostProcessingData postProcessingData = new PostProcessingData(fieldReport.getObjectType(), fieldReport.getActivityObjectId(), NiaObjectConstants.CV_AUTO_SUBMIT_TO_NIA);
        outboundTriggerService.insertOutboundTrigger(postProcessingData, MobilityServicesConstants.MOBILITY_TRIGGER_TYPE_105_ONLINE_REPORTS_POST_PROCESSING);
        log.info("Creating trigger to send document " + fieldReport.getActivityId() + "/" + fieldReport.getActivityObjectId() +" for midas postprocessing.");
        
        reportingExtractService.createTriggerRecord(fieldReport.getActivityObjectId(), fieldReport.getObjectType());
        
        return fieldReport.getActivityObjectUuid();
    }
}
