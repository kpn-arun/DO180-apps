package nz.govt.police.mobility.onlinereports.context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import nz.govt.police.common.xmlCalls.ServerContext;
import nz.govt.police.esb.EsbClientImpl;
import nz.govt.police.mobility.configuration.IApplicationConfiguration;
import nz.govt.police.mobility.configuration.IApplicationConfiguration.Esb;
import nz.govt.police.mobility.service.UserContext;
import nz.govt.police.service.InterfaceGatewaysConfiguration;

/**
 * No ESB connection required yet, so nothing set here
 * 
 * @author shce24
 *
 */
@Component
public class OnlineReportsGatewayInterfaceGatewaysConfig implements InterfaceGatewaysConfiguration {
	private static final long serialVersionUID = 1L;

	@Autowired
	private IApplicationConfiguration onlineReportsApplicationConfiguration;
	
	@Autowired
	private UserContext userContext;

    static {
        /*
         * There's no longer a need to use the Datapower registry.  By default EsbClientImpl uses the registry so we have to actively turn it off
         * until the option is removed entirely. 
         */
        EsbClientImpl.setUseRegistry(false);
    }	
	
	private static final String REST_QUERY_SERVICE = "Support";
	
	
	@Override
	public ServerContext getEsbServerContext() {
		Esb esb = onlineReportsApplicationConfiguration.getEsb();
        ServerContext serverContext = new ServerContext(esb.getRegistryUrl(), esb.getServiceUser(), esb.getServicePassword(), esb.getServiceUser(), REST_QUERY_SERVICE);
        serverContext.setEsbClientIdentifier(REST_QUERY_SERVICE);
        serverContext.setCallingUserId(userContext.getUserId());
        serverContext.setEuwId(userContext.getDeviceId());
        return serverContext;
	}

	@Override
	public ServerContext getEsbServerSystemContext() {
		Esb esb = onlineReportsApplicationConfiguration.getEsb();
		ServerContext serverContext = new ServerContext(esb.getRegistryUrl(), esb.getServiceUser(), esb.getServicePassword(), esb.getServiceUser(), REST_QUERY_SERVICE);
        serverContext.setEsbClientIdentifier(REST_QUERY_SERVICE);
        return serverContext;
	}

}
