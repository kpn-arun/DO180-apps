package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.NIA.Common.ApplicationConstants.NAME_TYPE_PREVIOUS;
import static nz.govt.police.NIA.Common.ApplicationConstants.NAME_TYPE_REAL;
import static nz.govt.police.NIA.Common.ApplicationConstants.OTC_PERSON;
import static nz.govt.police.NIA.Common.ApplicationConstants.SOURCE_POLICE;
import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.DATE_FORMAT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Email;
import nz.govt.police.mobility.onlinereports.om.Name;
import nz.govt.police.mobility.onlinereports.om.Phone;
import nz.govt.police.mobility.service.om.ActivityLink;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.ActivityPerson;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.noting.NotingPersonService;
import nz.govt.police.mobility.service.onduty.interfaces.IActivityLinkUtilService;
import nz.govt.police.mobility.service.onduty.util.NiaObjectUtils;
import nz.govt.police.mobility.service.util.IdFactory;
import nz.govt.police.service.nia.om.Person;
import nz.govt.police.service.nia.om.PhoneNumber;
import nz.govt.police.service.nia.om.PhoneNumberLink;

/**
 * Mapper to map PEGA Json to ActivityPerson
 * 
 * @author yhpw09
 *
 */
@Service
@CommonsLog
public class OnlineReportPersonMapper {

    @Autowired
    NotingPersonService notingPersonService;
    
    @Resource(name = "activityLinkUtilService")
    private IActivityLinkUtilService activityLinkUtilService;

    @Autowired
    OnlineReportCodedValueMapper codedValueMapper;
    
    public ActivityPerson mapPerson(nz.govt.police.mobility.onlinereports.om.Person person, Noting noting, Map<UUID, ActivityLocation> locationsUuidMap)
            throws OnlineReportException {
        ActivityPerson activityPerson = map(person, noting, locationsUuidMap);
        // Save
        notingPersonService.addNewNiaPersonToNoting(activityPerson, noting);
        return activityPerson;
    }
    
    private ActivityPerson map(nz.govt.police.mobility.onlinereports.om.Person person, Noting noting, Map<UUID, ActivityLocation> locationsUuidMap)
            throws OnlineReportException {
        log.debug("Create ActivityPerson from Online Report Form and add it to Nia Noting. Noting Id:" + noting.getNotingId());

        Person niaPerson = new Person();

        // names
        nz.govt.police.service.nia.om.Name currentNiaName = mapNiaName(person.getCurrentName(),
                new NCodedValue(CodeTableConstants.CT_NAME_TYPE, NAME_TYPE_REAL));
        niaPerson.setNamePreferred(currentNiaName);

        // previous names
        if (person.getPreviousName() != null) {
            nz.govt.police.service.nia.om.Name previousNiaName = mapNiaName(person.getPreviousName(),
                    new NCodedValue(CodeTableConstants.CT_NAME_TYPE, NAME_TYPE_PREVIOUS));
            niaPerson.setNamesAll(Stream.of(previousNiaName).collect(Collectors.toList()));
        }

        // phones
        List<Phone> phones = person.getPhones();
        if (phones != null) {
            List<PhoneNumberLink> niaPhones = new ArrayList<>();
            for (Phone onlineReportPhone : phones) {
                niaPhones.add(mapNiaPhoneNumber(onlineReportPhone));
            }
            niaPerson.setPhonesAll(niaPhones);
        }

        List<Email> emails = person.getEmails();
        if (emails != null) {
            // email
            // Validation makes sure there is exactly one email address
            niaPerson.setEmailAddress(emails.stream().filter(onlineReportsEmail -> onlineReportsEmail.isPrimary()).findFirst()
                    .map(email -> email.getEmailAddress()).orElseThrow());
        }

        // other details
        niaPerson.setGender(codedValueMapper.mapCodedValue(person.getGender(), false));

        IDate dob = NDateUtil.dateFromString(person.getBirthDate(), DATE_FORMAT);
        niaPerson.setBirthDate(dob);

        // Unusually, Office behaves different when dlicno is null as compared to when its blank string. NIA validates blank string and FMC tries to re query
        // person based on blank dlicno (if dlicno was null it would just try to re query on name instead)
        niaPerson.setDlicno(StringUtils.defaultIfBlank(person.getDlicno(), null));

        niaPerson.setSourceApplication(new NCodedValue(CodeTableConstants.CT_SOURCE_APPLICATION, SOURCE_POLICE));
        niaPerson.setObjectType(new NCodedValue(CodeTableConstants.CT_OBJECT_TYPE, OTC_PERSON));
        
        ActivityPerson activityPerson = NiaObjectUtils.niaPersonToActivityPerson(noting, niaPerson, false);
        
        //address. Assuming address uuid provided with person here is already validated against list of locations provided
        ActivityLink addressLink = activityLinkUtilService.createAndAddNewlink(activityPerson, locationsUuidMap.get(person.getAddress()),
                (int) codedValueMapper.mapCodedValue(person.getAddressType(), false).getCodeValue(), noting, true);
            
        activityPerson.setSelectedAddressLink(addressLink);    
        activityPerson.setSelectedAddressLinkUuid(addressLink.getActivityObjectLinkUuid());
        
        return activityPerson;
    }

    private nz.govt.police.service.nia.om.Name mapNiaName(Name onlineReportsName, ICodedValue nameType) {
        nz.govt.police.service.nia.om.Name niaName = new nz.govt.police.service.nia.om.Name();
        niaName.setLocalId(IdFactory.getId());
        niaName.setCreationDate(NDateUtil.dateNow());
        niaName.setCreationTime(NDateUtil.timeNow());
        niaName.setType(nameType);
        niaName.setFirstName(StringUtils.trim(onlineReportsName.getFirstName()));
        niaName.setFamilyName(StringUtils.trim(onlineReportsName.getFamilyName()));
        niaName.setMiddleNames(StringUtils.trim(onlineReportsName.getMiddleNames()));

        return niaName;
    }

    private PhoneNumberLink mapNiaPhoneNumber(Phone onlineReportsPhone) throws OnlineReportException {
        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.setLocalId(IdFactory.getId());
        PhoneNumberLink phoneNumberLink = new PhoneNumberLink();
        phoneNumberLink.setLocalId(IdFactory.getId());

        phoneNumberLink.setFullDetails(phoneNumber);
        phoneNumberLink.setStartDate(NDateUtil.dateNow());
        phoneNumberLink.setStartTime(NDateUtil.timeNow());
        phoneNumberLink.setPrimary(onlineReportsPhone.isPrimary());
        phoneNumberLink.setType(codedValueMapper.mapCodedValue(onlineReportsPhone.getType(), false));
        phoneNumber.setListing(new NCodedValue(CodeTableConstants.CT_TELEPHONE_LISTING, 1));
        phoneNumber.setCountryCode(codedValueMapper.mapCodedValue(onlineReportsPhone.getCountryCode(), false));
        phoneNumber.setAreaCode(StringUtils.trim(onlineReportsPhone.getAreaCode()));
        phoneNumber.setBaseNumber(StringUtils.trim(onlineReportsPhone.getNumber()));

        return phoneNumberLink;
    }
}