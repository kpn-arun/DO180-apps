package nz.govt.police.mobility.onlinereports.context;

import nz.govt.police.mobility.configuration.IApplicationConfiguration;
import nz.govt.police.mobility.configuration.IConfiguration;

/**
 * All null returns are basically to satisfy the interface that happens to be
 * the mobility service context. Gateway do not need those property values. The
 * are mainly for Mobility
 * 
 * @author yhpw09
 *
 */
public interface IOnlineReportsApplicationConfiguration extends IApplicationConfiguration {
	@Override
	default String getConfigUuid() {
		return null;
	}

	@Override
	default ConfigurationType getConfigurationType() {
		return IConfiguration.ConfigurationType.APPLICATION;
	}

	@Override
	default String getConfigurationInfo() {
		return null;
	}

	@Override
	default String getDbSchema() {
		return null;
	}

	@Override
	default String getJndiName() {
		return null;
	}

	@Override
	default String getOutboundTriggerTable() {
		return null;
	}

	@Override
	default Integer getOccurrenceTimeLimitMinutes() {
		return 0;
	}

	@Override
	default String getEhCacheCfgPath() {
		return null;
	}

	@Override
	default String getMediaServerUrl() {
		return null;
	}

	@Override
	default String getLocationServiceUrl() {
		return null;
	}

	@Override
	default String getImageServerUrl() {
		return null;
	}

	@Override
	default String getCyfEmailAddress() {
		return null;
	}

	@Override
	default String getEmails() {
		return null;
	}

	@Override
	default Esb getEsb() {
		return null;
	}

	@Override
	default ArcGisApi getArcGisApi() {
		return null;
	}

	@Override
	default HomeCareMedicalApi getHomeCareMedicalApi() {
		return null;
	}

	@Override
	default String getPibDmcEmailAddress() {
		return null;
	}

    @Override
    default Keycloak getKeycloak() {
        return new Keycloak() {
			
			@Override
			public String getUsername() {
				return null;
			}
			
			@Override
			public String getTokenRequestUrl() {
				return null;
			}
			
			@Override
			public String getPassword() {
				return null;
			}
			
			@Override
			public String getGrantType() {
				return null;
			}
			
			@Override
			public String getClientSecret() {
				return null;
			}
			
			@Override
			public String getClientId() {
				return null;
			}
		};
    }

    @Override
    default PropertyApi getPropertyApi() {
        return new PropertyApi() {
			
			@Override
			public String getBaseUrl() {
				return null;
			}
		};
    }
}
