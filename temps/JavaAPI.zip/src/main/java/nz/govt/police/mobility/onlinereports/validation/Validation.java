package nz.govt.police.mobility.onlinereports.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.onlinereports.om.Vehicle;

/**
 * The root of all validations
 * Ideally, this should be moved to spring custom hierarchical validations at controller level.
 * Gave it a quick go but didn't work well. Given more time I would definitely go that way. 
 * @author yhpw09
 *
 */
@Component
public class Validation extends AbstractValidation {

    @Autowired
    NiaObjectValidator personValidator;

    @Autowired
    NiaObjectValidator vehicleValidator;

    @Autowired
    NiaObjectValidator locationValidator;

    @Autowired
    ReportValidator reportValidator;

    /**
     * Accumulate all the messages and send all together in response. Since Validations are simpler we preferred to send back messages separated by comma. Other
     * option was to have an error object with attributes like http_code, actual message and serialize back object for each error message. Makes it more
     * structured and readable.
     */
    public void validate(OnlineReport onlineReport) throws OnlineReportException {

        OnlineReportErrors onlineReportErrors = new OnlineReportErrors();

        Report report = onlineReport.getReport();

        if (report == null) {
            onlineReportErrors.addError(null, "Missing value", "report");
        } else {
            reportValidator.validate(report, onlineReportErrors);
        }        

        if (onlineReport.getNiaObjects() != null) {
            validateNiaObjects(onlineReport, onlineReportErrors);
        } else {
            onlineReportErrors.addError(null, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObjects");
        }

        if (onlineReportErrors.hasErrors()) {
            throw new OnlineReportException("Validation Errors", onlineReportErrors);
        }
    }
    
    protected void validateNiaObject(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        if (niaObject instanceof Location) {
            locationValidator.validate(niaObject, onlineReportErrors);
        } else if (niaObject instanceof Vehicle) {
            vehicleValidator.validate(niaObject, onlineReportErrors);
        } else {
            personValidator.validate(niaObject, onlineReportErrors);
        }
    }
}