package nz.govt.police.mobility.onlinereports.context;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerMapping;

import nz.govt.police.common.database.NDatabaseUtil;
import nz.govt.police.common.database.NTransaction;
import nz.govt.police.common.database.NWebTransaction;
import nz.govt.police.mobility.onlinereports.controller.OnlineReportsController;
import nz.govt.police.mobility.service.VersionCheckRequestCache;
import nz.govt.police.mobility.service.om.ActivityObjectRequestCache;

@WebFilter({ "/*" })
public class OnlineReportsGatewayRequestFilter implements Filter { 
	
	@Autowired
	private OnlineReportsApplicationConfiguration applicationConfiguration;
	
	@Autowired
    private OnlineReportsGatewayRequest onlineReportsGatewayRequest;
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        
        try(FilterWrapper f = new FilterWrapper()) {
            String userId = "105USER";
            if (request instanceof HttpServletRequest
                    && StringUtils.endsWith(((HttpServletRequest) request).getRequestURI(), OnlineReportsController.COVID_19_SERVLET_PATH)) {
                userId = applicationConfiguration.getReportingUserId();
            }
            onlineReportsGatewayRequest.setUserId(userId);
            onlineReportsGatewayRequest.setDeviceType("D");
            
            chain.doFilter(request, response);

            /**
             * Written with the current assumption that everything other than HTTP Response 200 is a failure and would result in rollback.
             * If we start responding with other success codes say 201, the logic will fail and result in terrible bug. 
             * The other alternative would be to use Thread Local variable say 'isRollback' which will be set in Exception handling under OnlineReportsController 
             */
			if (((HttpServletResponse) response).getStatus() == HttpStatus.OK.value()) {
				f.commitTransaction = true;
			}
        } 
    }
    
    
    public class FilterWrapper implements AutoCloseable {

        boolean commitTransaction;
        public FilterWrapper() {
            ActivityObjectRequestCache.detach();
            VersionCheckRequestCache.detach();

            NDatabaseUtil.setJNDIName("java:comp/env/" + applicationConfiguration.getJndiName());
            new NWebTransaction();
        }

        @Override
        public void close() throws IOException {
            try {
				if (commitTransaction) {
					NTransaction.currentTransaction().commit();
				} else {
					NTransaction.rollbackTransaction();
				}
                NTransaction.currentConnection().close();

                ActivityObjectRequestCache.detach();
                VersionCheckRequestCache.detach();
            } 
            catch (SQLException e) {
                throw new IOException(e);
            }
        }
    }

}
