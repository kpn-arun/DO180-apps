package nz.govt.police.mobility.onlinereports.services;

import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportCovid19NotingMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportInformationAlertMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportLocationMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportPersonMapper;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.validation.Covid19Validation;
import nz.govt.police.mobility.service.Enums.WorkflowAction;
import nz.govt.police.mobility.service.MobilityServicesConstants;
import nz.govt.police.mobility.service.exception.StaleUpdateException;
import nz.govt.police.mobility.service.impl.OutboundTriggerService;
import nz.govt.police.mobility.service.interfaces.IWorkflowService;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.ActivityPerson;
import nz.govt.police.mobility.service.om.Holder;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.om.PostProcessingData;
import nz.govt.police.mobility.service.onduty.impl.noting.NotingSaveService;
import nz.govt.police.service.NiaObjectConstants;
import nz.govt.police.service.ServiceException;

@CommonsLog
@Service
public class Covid19AlertService extends AbstractReportService {

    @Autowired
    OnlineReportLocationMapper locationMapper;

    @Autowired
    OnlineReportPersonMapper personMapper;

    @Autowired
    OnlineReportCovid19NotingMapper covid19NotingMapper;

    @Autowired
    OutboundTriggerService outboundTriggerService;

    @Autowired
    IWorkflowService workflowService;

    @Autowired
    Covid19Validation covid19Validation;

    @Autowired
    NotingSaveService notingSaveService;
    
    @Autowired
    private OnlineReportsApplicationConfiguration applicationConfiguration;

    @Autowired
    OnlineReportInformationAlertMapper onlineReportInformationAlertMapper;

    public UUID createCovid19Alert(OnlineReport report) throws ServiceException, OnlineReportException {

        if (report.getReport() == null) {
            throw new OnlineReportException("No Noting information found.");
        }

        // validations
        log.info("Running validations: " + report.getReport().getReportUuid());

        covid19Validation.validate(report);

        log.info("Processing covid 19 alert: " + report.getReport().getReportUuid());

        Noting noting = covid19NotingMapper.mapNoting(report.getReport());

        // Nia Objects
        Map<String, List<NiaObject>> niaObjects = getNiaObjects(report);

        // Add record location
        ActivityLocation activityRecordLocation = null;
        Location recordLocation = null;
        if (niaObjects.get(RECORD_LOCATION_KEY).size() == 1) {
            recordLocation = (Location) niaObjects.get(RECORD_LOCATION_KEY).get(0);
            activityRecordLocation = locationMapper.mapRecordLocation(recordLocation, noting);
        }

        notingSaveService.saveNewLocally(noting);

        // add alert on record location
        if (activityRecordLocation != null) {
            onlineReportInformationAlertMapper.mapInformationAlert(noting, activityRecordLocation);
        }

        Noting previous = SerializationUtils.clone(noting);

        // Add Persons
        if (niaObjects.get(PERSON_KEY).size() == 1) {
            ActivityPerson activityPerson = personMapper.mapPerson((Person) niaObjects.get(PERSON_KEY).get(0), noting,
                    Map.ofEntries(new AbstractMap.SimpleEntry<UUID, ActivityLocation>(recordLocation.getUuid(), activityRecordLocation)));

            // add alert on person
            onlineReportInformationAlertMapper.mapInformationAlert(noting, activityPerson);
        }

        notingSaveService.saveInMobility(new Holder<Noting>(noting, previous));

        try {
            workflowService.changeWorkflowStatus(noting, WorkflowAction.SUBMIT, "", applicationConfiguration.getReportingUserId(), false);
            workflowService.changeWorkflowStatus(noting, WorkflowAction.ACCEPT, "", applicationConfiguration.getReportingUserId(), false);
        } catch (StaleUpdateException e) {
            throw new ServiceException(e);
        }

        PostProcessingData postProcessingData = new PostProcessingData(noting.getObjectType(), noting.getActivityObjectId(),
                NiaObjectConstants.CV_AUTO_SUBMIT_TO_NIA);
        outboundTriggerService.insertOutboundTrigger(postProcessingData, MobilityServicesConstants.MOBILITY_TRIGGER_TYPE_105_ONLINE_REPORTS_POST_PROCESSING);
        log.info("Creating trigger to send document " + noting.getActivityId() + "/" + noting.getActivityObjectId() + " for midas postprocessing.");

        // reportingExtractService.createTriggerRecord(noting.getActivityObjectId(), noting.getObjectType());

        return noting.getActivityObjectUuid();
    }
}
