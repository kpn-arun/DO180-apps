package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.service.NiaObjectConstants.CV_ATTACHMENT_TYPE_ONLINE_ATTACHMENT;
import static nz.govt.police.service.NiaObjectConstants.CV_ATTACHMENT_TYPE_ONLINE_REPORT;
import static nz.govt.police.service.NiaObjectConstants.CV_RECORD;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.InvalidMimeTypeException;
import org.springframework.util.MimeType;

import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Attachment;
import nz.govt.police.mobility.service.om.MobilityAttachment;

/**
 * Code for mapping PEGA Attachments to MobilityAttachments lives here
 * 
 * @author shce24
 *
 */
@Service
public class OnlineReportAttachmentMapper {
    
    public MobilityAttachment mapAttachment(Attachment attachment, Long activityId, Long notingId) throws OnlineReportException {
        validateAttachment(attachment);
        
        return new MobilityAttachment(null, 
                activityId, 
                notingId, 
                CV_RECORD, 
                CV_ATTACHMENT_TYPE_ONLINE_ATTACHMENT,
                attachment.getData(), 
                "O:\\" + attachment.getFilename().trim(),
                attachment.getDescription());
    }

    public MobilityAttachment mapPdf(Attachment originalPdf, Long activityId, Long notingId, String reportId) throws OnlineReportException {
        validateAttachment(originalPdf);
        
        return new MobilityAttachment(null, 
                activityId, 
                notingId, 
                CV_RECORD, 
                CV_ATTACHMENT_TYPE_ONLINE_REPORT,
                originalPdf.getData(), 
                "O:\\OnlineReport-" + reportId + ".pdf",
                "105 Online Report");
    }
    
    private void validateAttachment(Attachment attachment) throws OnlineReportException {

        if (attachment.getAttachmentUuid() == null) {
            throw new OnlineReportException("Attachment has no UUID.");
        }
        
        if (attachment.getData() == null) {
            throw new OnlineReportException("Attachment has no data, UUID is: " + attachment.getAttachmentUuid());
        }
        
        if (StringUtils.isBlank(attachment.getContentType())) {
            throw new OnlineReportException("Attachment has no content type, UUID is: " + attachment.getAttachmentUuid());
        }
        try {
            MimeType.valueOf(attachment.getContentType());
        }
        catch (InvalidMimeTypeException e) {
            throw new OnlineReportException("Attachment has an invalid mime type, UUID: " + attachment.getAttachmentUuid() + " MIME type: " + attachment.getContentType(), e);
        }
            
    }

}
