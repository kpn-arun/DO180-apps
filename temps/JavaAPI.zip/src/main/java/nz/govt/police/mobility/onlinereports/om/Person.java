package nz.govt.police.mobility.onlinereports.om;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * @author yhpw09
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
public class Person extends NiaObject {
    
	private Long niaPersonId;
	private Name currentName;
	private Name previousName;
	private CodedValue gender;
	private String birthDate;
	private String dlicno;
	private UUID address;
	private CodedValue addressType;
	private List<Email> emails;
	private List<Phone> phones;
}
