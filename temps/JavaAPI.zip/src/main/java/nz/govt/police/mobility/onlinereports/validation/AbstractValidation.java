package nz.govt.police.mobility.onlinereports.validation;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Person;

public abstract class AbstractValidation {

    protected void validateNiaObjects(OnlineReport onlineReport, OnlineReportErrors onlineReportErrors) {

        UUID reportUuid = onlineReport.getReport() != null ? onlineReport.getReport().getReportUuid() : null;

        Map<UUID, NiaObject> locations = onlineReport.getNiaObjects().stream().filter(niaObjects -> niaObjects instanceof Location)
                .collect(Collectors.toMap(NiaObject::getUuid, niaObject -> niaObject, (a1, a2) -> a1));
        if (CollectionUtils.isEmpty(locations)) {
            onlineReportErrors.addError(null, "No locations specified", "niaObjects");
        }

        // Check if record location exist
        UUID location = onlineReport.getReport() != null ? onlineReport.getReport().getLocation() : null;
        if (locations.get(location) == null) {
            onlineReportErrors.addError(reportUuid, "Cannot find the report location", "report.location", location != null ? location.toString() : null);
        }

        validateNiaObjects(reportUuid, onlineReport, locations, onlineReportErrors);
    }

    protected void validateNiaObjects(UUID reportUuid, OnlineReport onlineReport, Map<UUID, NiaObject> locations, OnlineReportErrors onlineReportErrors) {
        Map<UUID, NiaObject> allObjects = new HashMap<>();
        int index = 0;
        for (NiaObject niaObject : onlineReport.getNiaObjects()) {
            UUID niaObjectUuid = niaObject.getUuid();

            if (niaObjectUuid == null) {
                onlineReportErrors.addError(reportUuid, AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, String.format("niaObject[%s].uuid", index));
                // no need to continue
                continue;
            }

            if (allObjects.containsKey(niaObject.getUuid())) {
                onlineReportErrors.addError(reportUuid, "Duplicate value", String.format("niaObject[%s].uuid", index), niaObjectUuid.toString());
            }

            // This line will always come after contains check above
            allObjects.put(niaObject.getUuid(), niaObject);

            validateNiaObject(niaObject, onlineReportErrors);

            // extra bit to check if persons address is provided
            if (niaObject instanceof Person) {
                UUID personAddress = ((Person) niaObject).getAddress();
                if (locations.get(personAddress) == null) {
                    onlineReportErrors.addError(niaObjectUuid, "Does not have a corresponding location object", "person.address",
                            personAddress != null ? personAddress.toString() : null);
                }
            }
        }
    }

    protected abstract void validateNiaObject(NiaObject niaObject, OnlineReportErrors onlineReportErrors);
}
