package nz.govt.police.mobility.onlinereports.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nz.govt.police.NIA.Common.ApplicationConstants;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;

public class AbstractReportService {

    public static final String DATE_FORMAT =  "yyyy-MM-dd";
    public static final String TIME_FORMAT = "HH:mm:ss";
    
    protected final String PERSON_KEY = "PERSON";
    protected final String LOCATION_KEY = "LOCATION";
    protected final String VEHICLE_KEY = "VEHICLE";
    protected final String RECORD_LOCATION_KEY = "RECORD_LOCATION";
    
    protected Map<String, List<NiaObject>> getNiaObjects(OnlineReport report) {
        Map<String, List<NiaObject>> niaObjects = new HashMap<>();
        niaObjects.put(VEHICLE_KEY, new ArrayList<>());
        niaObjects.put(LOCATION_KEY, new ArrayList<>());
        niaObjects.put(PERSON_KEY, new ArrayList<>());
        niaObjects.put(RECORD_LOCATION_KEY, new ArrayList<>());

        for (NiaObject niaObject : report.getNiaObjects()) {
            // Should be null safe by now otherwise validation would fail
            final int objectTypeCodedValue = (int) niaObject.getObjectType().getCodeValue().longValue();            
            switch (objectTypeCodedValue) {
            case ApplicationConstants.OTC_VEHICLE:
                niaObjects.get(VEHICLE_KEY).add(niaObject);
                break;
            case ApplicationConstants.OTC_LOCATION:
                if (niaObject.getUuid().equals(report.getReport().getLocation())) {
                    niaObjects.get(RECORD_LOCATION_KEY).add(niaObject);
                } else {
                    niaObjects.get(LOCATION_KEY).add(niaObject);
                }
                break;
            case ApplicationConstants.OTC_PERSON:
                niaObjects.get(PERSON_KEY).add(niaObject);
                break;
            }
        }

        return niaObjects;
    }

}
