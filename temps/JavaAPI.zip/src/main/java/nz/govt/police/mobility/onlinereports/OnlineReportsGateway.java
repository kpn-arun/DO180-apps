package nz.govt.police.mobility.onlinereports;

import javax.sql.DataSource;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.apache.tomcat.util.descriptor.web.NamingResources;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;

@CommonsLog
@SpringBootApplication
@EnableCaching(proxyTargetClass = true)
@ComponentScan(basePackages = {"nz.govt.police.spring", "nz.govt.police.mobility", "nz.govt.police.homecare", "nz.govt.police.arcgis", "nz.govt.police.nia.location", "nz.govt.police.service" })
@ServletComponentScan
public class OnlineReportsGateway {
	
	@Autowired
	private OnlineReportsApplicationConfiguration applicationConfiguration;

    public static void main(String[] args) {
        
        // fix for warning "Using deprecated META-INF/services mechanism with non-standard property: javax.xml.soap.MetaFactory. Property javax.xml.soap.SAAJMetaFactory should be used instead." 
        // as per https://github.com/javaee/metro-jax-ws/issues/1237
        System.setProperty("javax.xml.soap.SAAJMetaFactory", "com.sun.xml.messaging.saaj.soap.SAAJMetaFactoryImpl");
        
        SpringApplication.run(OnlineReportsGateway.class, args);
    }
    
    /**
     * The following is needed to setup and enable the required database JNDI names.
     * 
     */
    @Bean
    public TomcatServletWebServerFactory tomcatFactory() {
        return new TomcatServletWebServerFactory() {

            @Value("${spring.datasource.jdbcUrl}")
            String url;

            @Value("${spring.datasource.username}")
            String userName;

            @Value("${spring.datasource.password}")
            String password;

            @Value("${spring.datasource.driver-class-name}")
            String driverClassName;

            @Override
            protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
                tomcat.enableNaming();
                return super.getTomcatWebServer(tomcat);
            }

            @Override
            protected void postProcessContext(Context context) {
                NamingResources namingResources = context.getNamingResources();
                namingResources.addResource(newResource(applicationConfiguration.getJndiName(), url, userName, password));
            }

            private ContextResource newResource(String name, String url, String username, String password) {
                ContextResource resource = new ContextResource();
                resource.setName(name);
                resource.setType(DataSource.class.getName());
                resource.setProperty("jdbcUrl", url);
                resource.setProperty("username", username);
                resource.setProperty("password", password);
                resource.setProperty("driverClassName", driverClassName);
                resource.setProperty("factory", "com.zaxxer.hikari.HikariJNDIFactory");
                return resource;
            }
        };
    }
    
    @Primary
    @Bean
    public Jackson2ObjectMapperBuilder configureMapper() {
        return new Jackson2ObjectMapperBuilder() {
            @Override
            public void configure(ObjectMapper objectMapper) {
                super.configure(objectMapper);
                log.info("Jackson object mapper configured");
            }
        };
    }
        

}