package nz.govt.police.mobility.onlinereports.validation;

import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.TIME_FORMAT;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.interfaces.ITimestamp;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.service.NiaObjectConstants;

/**
 * Ideally this didn't need to be abstract class. Rather a service. Will do when time permits
 * @author yhpw09
 *
 */
@CommonsLog
public abstract class AbstractValidator {
    
    public static final String ERROR_MESSAGE_FOR_BLANK_VALUE = "Blank value";
    public static final String ERROR_MESSAGE_FOR_INVALID_VALUE = "Invalid value";
    public static final String ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE = "Blank or invalid value";
    public static final String ERROR_MESSAGE_DATE_IN_FUTURE = "Date cannot be in the future";
    
    @Autowired
    private CodedValueValidator codedValueValidator;

    /**
     * Performs strict validation on date format.
     * SimpleDateFormat does not always perform strict validation e.g '70-07-12' for format 'yyyy-MM-dd' should have failed but returns '0070-07-12.
     * Similarly '1970-31-12' for format 'yyyy-MM-dd' should have failed but returns '12-07-1972'
     * Other way was to use Java 8 DateTimeFormatter but I guess inverse comparison makes it even more strict
     */
    protected IDate validateDate(String dateString) {
        try {
            IDate date = NDateUtil.validateDate(dateString, DATE_FORMAT);
            if (date == null) {
                return null;
            }
            if (StringUtils.equals(NDateUtil.format(date, DATE_FORMAT), dateString)) {
                return date;
            }
        } catch (Exception e) {
            log.debug("Error parsing date:" + dateString + ". Details:" + e.getMessage());
            return null;
        }

        return null;
    }

    /**
     * Performs strict validation on time format.
     */
    protected ITime validateTime(String timeString) {
        try {
            ITime time = NDateUtil.validateTime(timeString, TIME_FORMAT);
            if (time == null) {
                return null;
            }
            if (StringUtils.equals(NDateUtil.format(time, TIME_FORMAT), timeString)) {
                return time;
            }
        } catch (Exception e) {
            log.debug("Error parsing time:" + timeString + ". Details:" + e.getMessage());
            return null;
        }
        
        return null;
    }
    
    protected void validateCode(UUID uuid, OnlineReportErrors onlineReportErrors, String field, CodedValue codedValue, int codeTableId) {
        if (!codedValueValidator.isCodeTableValid(codedValue, codeTableId)) {
            onlineReportErrors.addError(uuid, AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, field, codedValue != null ? codedValue.toString() : null);
        }
    }
    
    protected void validateCodeMandatory(UUID uuid, OnlineReportErrors onlineReportErrors, String field, String message, CodedValue codedValue, int codeTableId) {
        if (!codedValueValidator.isCodeTableValid(codedValue, codeTableId, true)) {
            onlineReportErrors.addError(uuid, message, field, codedValue != null ? codedValue.toString() : null);
        }
    }
    
    protected ITimestamp getTS(IDate startDate, ITime startTime) {
        if (startDate == null) {
            return null;
        }
        
        return NDateUtil.tsFromNDateAndNTime(startDate, startTime == null ? NiaObjectConstants.DEFAULT_TIME : startTime);
    }
}
