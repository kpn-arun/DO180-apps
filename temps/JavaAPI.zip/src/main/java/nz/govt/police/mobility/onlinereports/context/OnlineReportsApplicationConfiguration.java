package nz.govt.police.mobility.onlinereports.context;

import java.net.URL;

import javax.validation.constraints.NotNull;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.UrlResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import lombok.Getter;
import lombok.Setter;
import nz.govt.police.mobility.onlinereports.deserializer.NiaObjectJsonDeserializer;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.service.ServicesSpringConfiguration;

/**
 * 105 Gateway specific properties to satisfy Mobility Service Spring managed
 * dependencies
 * 
 * @author yhpw09
 *
 */
@Configuration
@Import(ServicesSpringConfiguration.class)
public class OnlineReportsApplicationConfiguration implements IOnlineReportsApplicationConfiguration {
	@Getter
	@Value("${OUTBOUND_TRIGGER_TABLE:MOBILITY.OUTBOUND_TRIGGER}")
	private String outboundTriggerTable;

	@Getter
	@NotNull
	@Value("${spring.datasource.jndi-name}")
	private String jndiName;

	@Getter
	@NotNull
	@Value("${LOCATION_SERVICE_URL}")
	private String locationServiceUrl;

	@Value("${app.esb.url}")
	@NotNull
	private String url;

	@Value("${app.esb.username:username}")
	private String username;

	@Value("${app.esb.password:password}")
	private String password;
	
	@Getter
    @Value("${ehCacheCfgPath:classpath:ehcache.xml}")
    private String ehCacheCfgPath;
	
	@Getter
	@Setter
    @Value("${reporting.user.id}")
    private String reportingUserId;

	@Getter
	private Esb esb = new Esb() {
		@Override
		public String getRegistryUrl() {
			return url;
		}

		@Override
		public String getServiceUser() {
			return username;
		}

		@Override
		public String getServicePassword() {
			return password;
		}
	};

	@Bean(name = "cacheManagerFactoryBean")
	public EhCacheManagerFactoryBean getCacheManagerFactoryBean() {
		if (ehCacheCfgPath == null) {
			throw new RuntimeException("null ehCacheCfgPath configuration value.");
		}
		try {
			URL ehCacheCfgPathUrl = new URL(ehCacheCfgPath);
			EhCacheManagerFactoryBean ehCacheManagerFactoryBean = new EhCacheManagerFactoryBean();
			ehCacheManagerFactoryBean.setShared(true);
			ehCacheManagerFactoryBean.setConfigLocation(new UrlResource(ehCacheCfgPathUrl));
			return ehCacheManagerFactoryBean;
		} catch (Exception e) {
			throw new RuntimeException(
					e.getClass().getName() + " thrown configuring cache manager: " + e.getMessage());
		}
	}

	// Custom deserializers. Annotation '@JsonDeserialize' on object to be dederialized didn't work
	@Bean
	public ObjectMapper objectMapper() {
		SimpleModule module = new SimpleModule();
		module.addDeserializer(NiaObject.class, new NiaObjectJsonDeserializer());
		return new ObjectMapper().registerModules(module);
	}
}