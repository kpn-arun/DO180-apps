package nz.govt.police.mobility.onlinereports.om;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiError {

    private String uuid;
    private String field;
    private String message; 
    private String originalValue;
}
