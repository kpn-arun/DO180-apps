package nz.govt.police.mobility.onlinereports.validation;

import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.NiaObject;

public interface NiaObjectValidator {
    
    int VEHICLE_REG_NO_MAX_LENGTH = 6;
    int PERSON_FIRST_NAME_MAX_LENGTH = 30;
    int PERSON_FAMILY_NAME_MAX_LENGTH = 40;
    int PERSON_MIDDLE_NAMES_MAX_LENGTH = 60;
    int PERSON_EMAIL_MAX_LENGTH = 256;
    int PHONE_AREA_CODE_MAX_LENGTH = 4;
    int PHONE_NUMBER_MAX_LENGTH = 12;
    int IDENTIFYING_FEATURES_MAX_LENGTH = 250;
    String VALID_DLICNO_REGEX = "[A-Z]{2}[0-9]{6}";

    void validate(NiaObject niaObject, OnlineReportErrors onlineReportErrors);
    
    default void validateBasic(NiaObject niaObject, OnlineReportErrors onlineReportErrors) {
        
    }
}
