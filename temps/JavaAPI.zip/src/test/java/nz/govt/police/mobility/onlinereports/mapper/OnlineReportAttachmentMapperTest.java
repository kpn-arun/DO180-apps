package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.service.NiaObjectConstants.CV_ATTACHMENT_TYPE_ONLINE_ATTACHMENT;
import static nz.govt.police.service.NiaObjectConstants.CV_ATTACHMENT_TYPE_ONLINE_REPORT;
import static nz.govt.police.service.NiaObjectConstants.CV_RECORD;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.UUID;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;

import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Attachment;
import nz.govt.police.mobility.service.om.MobilityAttachment;

public class OnlineReportAttachmentMapperTest {

	@InjectMocks
	private OnlineReportAttachmentMapper objectToTest;

	private Attachment attachment;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@Before
	public void setup() throws Exception {
		initMocks(this);
		attachment = new Attachment();
	}

	@Test
	public void mapAttachment_throws_noUUID_exception() throws Exception {
		expectedEx.expect(OnlineReportException.class);
		expectedEx.expectMessage("Attachment has no UUID");
		objectToTest.mapAttachment(attachment, 1L, 2L);
	}

	@Test
	public void mapAttachment_throws_no_data_exception() throws Exception {
		attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));

		expectedEx.expect(OnlineReportException.class);
		expectedEx.expectMessage("Attachment has no data, UUID is: 70989a1a-c4a2-4b10-88aa-e2ffc36084cb");

		objectToTest.mapAttachment(attachment, 1L, 2L);
	}

	@Test
	public void mapAttachment_throws_no_content_type_exception() throws Exception {
		attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));
		attachment.setData("YmxhaGJsYWg=".getBytes());

		expectedEx.expect(OnlineReportException.class);
		expectedEx.expectMessage("Attachment has no content type, UUID is: 70989a1a-c4a2-4b10-88aa-e2ffc36084cb");

		objectToTest.mapAttachment(attachment, 1L, 2L);
	}

	@Test
	public void mapAttachment_throws_invalid_content_type_exception() throws Exception {
		attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));
		attachment.setData("YmxhaGJsYWg=".getBytes());
		attachment.setContentType("random");

		expectedEx.expect(OnlineReportException.class);
		expectedEx.expectMessage(
				"Attachment has an invalid mime type, UUID: 70989a1a-c4a2-4b10-88aa-e2ffc36084cb MIME type: random");

		objectToTest.mapAttachment(attachment, 1L, 2L);
	}

	@Test
	public void mapAttachment_successfully_create_mobility_attachment() throws Exception {
		attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));
		attachment.setData("YmxhaGJsYWg=".getBytes());
		attachment.setDescription("test description");
		attachment.setContentType("application/pdf");
		attachment.setFilename("test.pdf");

		MobilityAttachment attachmentResp = objectToTest.mapAttachment(attachment, 1L, 2L);
		
		assertEquals("O:\\test.pdf", attachmentResp.getAttachmentFilename());
		assertEquals(CV_RECORD, attachmentResp.getObjectType());
        assertEquals(CV_ATTACHMENT_TYPE_ONLINE_ATTACHMENT, attachmentResp.getAttachmentType());
        assertEquals("test description", attachmentResp.getAttachmentDescription());
        assertArrayEquals("YmxhaGJsYWg=".getBytes(), attachmentResp.getAttachmentData());
        assertEquals(1l, attachmentResp.getActivityId().longValue());
        assertEquals(2l, attachmentResp.getObjectId().longValue());
        
	}
	
	@Test
	public void mapAttachment_successfully_create_pdf() throws Exception {
		attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));
		attachment.setData("nkjv7658j".getBytes());
		attachment.setContentType("application/pdf");
		attachment.setFilename("anything.pdf");

		MobilityAttachment attachmentResp = objectToTest.mapPdf(attachment, 1L, 2L, "OR-ID-555");
		
		assertEquals("O:\\OnlineReport-OR-ID-555.pdf", attachmentResp.getAttachmentFilename());
		assertEquals(CV_RECORD, attachmentResp.getObjectType());
        assertEquals(CV_ATTACHMENT_TYPE_ONLINE_REPORT, attachmentResp.getAttachmentType());
        assertEquals("105 Online Report", attachmentResp.getAttachmentDescription());
        assertArrayEquals("nkjv7658j".getBytes(), attachmentResp.getAttachmentData());
        assertEquals(1l, attachmentResp.getActivityId().longValue());
        assertEquals(2l, attachmentResp.getObjectId().longValue());
        
	}	
}