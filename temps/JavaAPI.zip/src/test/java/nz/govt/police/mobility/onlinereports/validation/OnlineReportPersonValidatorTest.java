package nz.govt.police.mobility.onlinereports.validation;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.xml.client.codeTables.LoadCodeTable.CodeTableDetails;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.onlinereports.om.Email;
import nz.govt.police.mobility.onlinereports.om.Name;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Phone;
import nz.govt.police.service.impl.CodeTableService;

public class OnlineReportPersonValidatorTest extends AbstractOnlineReportValidatorTest {

    @Mock
    private CodeTableService codeTableService;

    PersonValidator personValidator;

    @Before
    public void setup() throws Exception {
        initMocks(this);

        onlineReportErrors = new OnlineReportErrors();
        personValidator = new PersonValidator();
      
        CodedValueValidator codedValidator = new CodedValueValidator();
        codedValidator.codeTableService = codeTableService;
        
        Whitebox.setInternalState(personValidator, "codedValueValidator", codedValidator);
        
        CodeTableDetails codeTableDetails = new CodeTableDetails();
        codeTableDetails.setCodeTableId(2759L);
        codeTableDetails.setValue(2L);
        Mockito.when(codeTableService.getCode(Mockito.any(ICodedValue.class))).thenReturn(codeTableDetails); 
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoDetailsProvided() throws OnlineReportException {
        Person person = Person.builder().build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.currentName"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidFirstNameProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("loooooooooooooooooooooooooooooooooooooong").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "firstName"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testMissingFirstNameProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "firstName"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidFamilyNameProvided() throws OnlineReportException {
        Person person = Person.builder()
                .currentName(
                        Name.builder().firstName("Steve").familyName("Smith Looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "familyName"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testMissingFamilyNameProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("Steve").familyName(" ").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "familyName"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidMiddleNamesProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("Steve").familyName("Smith")
                .middleNames("looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "middleNames"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoMiddleNamesProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "middleNames"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoDobProvided() throws OnlineReportException {
        Person person = Person.builder().currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.birthDate"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidDobProvided() throws OnlineReportException {
        Person person = Person.builder().birthDate("invalid-format").currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.birthDate", "invalid-format"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoAddressProvided() throws OnlineReportException {
        Person person = Person.builder().birthDate("invalid-format").currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.address"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidAddressTypeProvided() throws OnlineReportException {
        CodedValue invalidAddressType = CodedValue.builder().codeTableId(22l).codeValue(44l).build();
        Person person = Person.builder().address(UUID.randomUUID()).addressType(invalidAddressType)
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.addressType", invalidAddressType.toString()));
    }

    /**
     * 
     * @105 @api_gateway @person
     */
    @Test
    public void testValidAddressTypeProvided() throws OnlineReportException {
        CodedValue validAddressType = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_PERSON_ADDRESS_CODES).codeValue(44l).build();
        Person person = Person.builder().address(UUID.randomUUID()).addressType(validAddressType)
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.addressType", validAddressType.toString()));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoGenderProvided() throws OnlineReportException {
        Person person = Person.builder().address(UUID.randomUUID()).currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.gender"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidGenderProvided() throws OnlineReportException {
        CodedValue invalidGender = CodedValue.builder().codeTableId(88l).codeValue(44l).build();
        Person person = Person.builder().address(UUID.randomUUID()).gender(invalidGender)
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.gender", invalidGender.toString()));
    }

    /**
     * @105 @api_gateway @person
     */
    @Test
    public void testValidGenderProvided() throws OnlineReportException {
        CodedValue validGender = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_GENDER).codeValue(44l).build();
        Person person = Person.builder().address(UUID.randomUUID()).currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.gender", validGender.toString()));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidDlicnoProvided() throws OnlineReportException {
        Person person = Person.builder().address(UUID.randomUUID()).dlicno("DM1234").currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.dlicno", "DM1234"));
    }

    /**
     * 
     * @105 @api_gateway @person
     */
    @Test
    public void testValidDlicnoProvided() throws OnlineReportException {
        Person person = Person.builder().address(UUID.randomUUID()).dlicno("DM123456")
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.dlicno", "DM1234"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoEmailsProvided() throws OnlineReportException {
        Person person = Person.builder().address(UUID.randomUUID()).dlicno("DM123456")
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.emails"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testMorethanOnePrimaryEmailProvided() throws OnlineReportException {
        List<Email> emails = Stream.of(Email.builder().emailAddress("test").primary(true).build(), Email.builder().emailAddress("test1").primary(true).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).emails(emails).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError("person must have exactly one primary email", "niaObject.emails"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoPrimaryEmailProvided() throws OnlineReportException {
        List<Email> emails = Stream
                .of(Email.builder().emailAddress("test").primary(false).build(), Email.builder().emailAddress("test1").primary(false).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).emails(emails).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError("person must have exactly one primary email", "niaObject.emails"));
    }

    /**
     * 
     * @105 @api_gateway @person
     */
    @Test
    public void testValidEmailsProvided() throws OnlineReportException {
        List<Email> emails = Stream.of(Email.builder().emailAddress("test").primary(true).build(), Email.builder().emailAddress("test1").primary(false).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).emails(emails).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError("person must have exactly one primary email", "niaObject.emails"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoPhonesProvided() throws OnlineReportException {
        Person person = Person.builder().address(UUID.randomUUID()).dlicno("DM123456")
                .currentName(Name.builder().firstName("Steve").familyName("Smith").build()).build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaObject.phones"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testMorethanOnePrimaryPhoneProvided() throws OnlineReportException {
        List<Phone> phones = Stream.of(Phone.builder().primary(true).build(), Phone.builder().primary(true).build()).collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError("person must have exactly one primary phone", "niaObject.phones"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testNoPrimaryPhoneProvided() throws OnlineReportException {
        List<Phone> phones = Stream.of(Phone.builder().primary(false).build(), Phone.builder().primary(false).build()).collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError("person must have exactly one primary phone", "niaObject.phones"));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidPhoneTypeProvided() throws OnlineReportException {
        CodedValue invalidPhoneType = CodedValue.builder().codeTableId(11l).codeValue(12l).build();
        List<Phone> phones = Stream.of(Phone.builder().primary(true).type(invalidPhoneType).build(), Phone.builder().primary(false).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].type", invalidPhoneType.toString()));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testValidPhoneTypeProvided_v1() throws OnlineReportException {
        CodedValue validPhoneType = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_PERSON_TELEPHONE_CODES).codeValue(12l).build();
        List<Phone> phones = Stream.of(Phone.builder().primary(true).type(validPhoneType).build(), Phone.builder().primary(false).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].type", validPhoneType.toString()));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].type", null));
    }

    /**
     * @105 @api_gateway @person
     */
    @Test
    public void testValidPhoneTypeProvided_v2() throws OnlineReportException {
        CodedValue validPhoneType = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_PERSON_TELEPHONE_CODES).codeValue(12l).build();
        List<Phone> phones = Stream.of(Phone.builder().primary(true).type(validPhoneType).build(), Phone.builder().primary(false).type(validPhoneType).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].type", validPhoneType.toString()));
        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].type", validPhoneType.toString()));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidCountryCodeProvided() throws OnlineReportException {
        CodedValue invalidCountryCode = CodedValue.builder().codeTableId(11l).codeValue(12l).build();
        List<Phone> phones = Stream.of(Phone.builder().primary(true).countryCode(invalidCountryCode).build(), Phone.builder().primary(false).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].countryCode", invalidCountryCode.toString()));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].countryCode", null));
    }

    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testValidCountryCodeProvided_v1() throws OnlineReportException {
        CodedValue validCountryCode = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_TELEPHONE_COUNTRY_CODE).codeValue(12l).build();
        CodedValue invalidCountryCode = CodedValue.builder().codeTableId(11l).codeValue(12l).build();
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).countryCode(validCountryCode).build(), Phone.builder().primary(false).countryCode(invalidCountryCode).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].countryCode", validCountryCode.toString()));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].countryCode", invalidCountryCode.toString()));
    }

    /**
     * @105 @api_gateway @person
     */
    @Test
    public void testValidCountryCodeProvided_v2() throws OnlineReportException {
        CodedValue validCountryCode = CodedValue.builder().codeTableId((long) CodeTableConstants.CT_TELEPHONE_COUNTRY_CODE).codeValue(12l).build();
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).countryCode(validCountryCode).build(), Phone.builder().primary(false).countryCode(validCountryCode).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].countryCode", validCountryCode.toString()));
        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].countryCode", validCountryCode.toString()));
    }
    
    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidAreaCodeProvided() throws OnlineReportException {
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).areaCode("not-numeric").build(), Phone.builder().primary(false).areaCode("").build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.phones[0].areaCode", "not-numeric"));
    }
    
    /**
     * @105 @api_gateway @person
     */
    @Test
    public void testValidAreaCodeProvided() throws OnlineReportException {
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).areaCode("1234").build(), Phone.builder().primary(false).areaCode("1234").build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError("Invalidnvalid value", "niaObject.phones[0].areaCode", "123456"));
        assertTrue(!containsError("Invalidnvalid value", "niaObject.phones[1].areaCode", "123456"));
    }
    
    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidPhoneNumbersProvided_v1() throws OnlineReportException {
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).number("not-numeric").build(), Phone.builder().primary(false).number(null).build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].number", "not-numeric"));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].number", null));
    }
    
    /**
     * 
     * @105 @api_gateway @person @validation
     */
    @Test
    public void testInValidPhoneNumbersProvided_v2() throws OnlineReportException {
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).number("").build(), Phone.builder().primary(false).number("12345678912345").build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].number", ""));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].number", "12345678912345"));
    }
    
    /**
     * @105 @api_gateway @person
     */
    @Test
    public void testValidPhoneNumbersProvided() throws OnlineReportException {
        List<Phone> phones = Stream
                .of(Phone.builder().primary(true).number("123456789").build(), Phone.builder().primary(false).number("123456").build())
                .collect(Collectors.toList());

        Person person = Person.builder().address(UUID.randomUUID()).phones(phones).currentName(Name.builder().firstName("Steve").familyName("Smith").build())
                .build();

        personValidator.validate(person, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[0].number", "123456789"));
        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.phones[1].number", "123456"));
    }


}