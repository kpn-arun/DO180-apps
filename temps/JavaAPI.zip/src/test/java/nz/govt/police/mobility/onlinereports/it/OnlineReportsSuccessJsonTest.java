package nz.govt.police.mobility.onlinereports.it;

import static nz.govt.police.NIA.Common.ApplicationConstants.ATTACHMENT_TYPE_ONLINE_ATTACHMENT;
import static nz.govt.police.NIA.Common.ApplicationConstants.ATTACHMENT_TYPE_ONLINE_REPORT;
import static nz.govt.police.NIA.Common.ApplicationConstants.OTC_RECORD;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.springframework.http.HttpStatus.OK;

import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;

import nz.govt.police.common.database.NDatabaseUtil;
import nz.govt.police.common.database.NTransaction;
import nz.govt.police.common.database.NWebTransaction;
import nz.govt.police.mobility.onlinereports.om.ApiResponse;
import nz.govt.police.mobility.onlinereports.om.Attachment;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.impl.AttachmentService;
import nz.govt.police.mobility.service.impl.RecordService;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.FieldReport;
import nz.govt.police.mobility.service.om.MobilityAttachment;
import nz.govt.police.service.entities.nia.location.Location;

/**
 * Runs the json samples in the error_json directory as separate junit tests
 * 
 * @author shce24
 *
 */
@RunWith(Parameterized.class)
public class OnlineReportsSuccessJsonTest extends OnlineReportsMultiTest {
    
    private final static long CT_UNIT_TYPE_FLAT_CODE_VALUE = 7L;
        
    @Value("${spring.datasource.jndi-name}")
    private String jndiName;    
    
    @Inject
    private RecordService recordService;    

    @Inject
    private AttachmentService attachmentService;       
    
    public OnlineReportsSuccessJsonTest(File file) {
        super(file);
    }
    
    @Parameters(name = "{0}")
    public static Collection<Object[]> data() {
        return getFiles("success_json");
    }
    
    /**
     * Checks all the data in the supplied JSON against the mobility field report that the gateway created
     * 
     * @throws Exception
     */
    // @105 @api_gateway    
    @Test
    public void testSuccessJson() throws Exception {

        // hit the gateway with the file and check we get a 200 back
        ResponseEntity<String> response = testJson(OK);
        
        // get the response as an object with jackson so we can interrogate it
        ApiResponse apiResponse = objectMapper.readValue(response.getBody(), ApiResponse.class);
        
        // get the request as an object with jackson so we can interrogate it
        var onlineReport = objectMapper.readValue(reportAsString, OnlineReport.class);

        // basic response checks
        assertEquals(OK.value(), apiResponse.getStatus());
        assertNotNull(apiResponse.getPoliceReportUuid());
        assertEquals(onlineReport.getReport().getReportUuid(), apiResponse.getReportUuid());
        
        // load the mobility field report from the database
        NDatabaseUtil.setJNDIName("java:comp/env/" + jndiName);
        new NWebTransaction();
        
        FieldReport fieldReport = recordService.getRecord(apiResponse.getPoliceReportUuid(), RecordService.Reference.ActivityObjectsAndLinks);
        
        // verify the data from mobility against that loaded from the data
        verifyReport(fieldReport, onlineReport);
        verifyLocation(fieldReport, onlineReport);
        verifyPdfCopy(fieldReport, onlineReport);
        verifyAttachments(fieldReport, onlineReport);
        
        NTransaction.currentTransaction().commit();
        NTransaction.currentConnection().close();

    }
    
    /**
     * Verifies that the record location in the Online Report was saved correctly into Mobility as the field report record location
     * 
     * @param fieldReport
     * @param onlineReport
     */
    private void verifyLocation(FieldReport fieldReport, OnlineReport onlineReport) {
        
        // find the record location from the list of objects
        nz.govt.police.mobility.onlinereports.om.Location location = (nz.govt.police.mobility.onlinereports.om.Location) onlineReport.getNiaObjects().stream().collect(Collectors.toMap(NiaObject::getUuid, Function.identity())).get(onlineReport.getReport().getLocation());
        ActivityLocation recordLocation = fieldReport.getRecordLocation();
        Location niaLocation = recordLocation.getLocation();
        
        // locations must be type 4
        assertEquals(4l, location.getObjectType().getCodeValue().longValue());
        
        // if the JSON had a NIA location, check we've set it as the record location
        if (location.getNiaLocationId() != null) {
            assertEquals(location.getNiaLocationId(), recordLocation.getNiaObjectId());
        }
        
        // if the JSON has a suburb town then we're a new NIA location
        else if (location.getSuburbTown() != null) {
            assertEquals(location.getSuburbTown().getCodeValue().longValue(), niaLocation.getTownSuburb().getCodeValue());
            verifyLocationFields(niaLocation, location);
            
            // new locations default to this scene station (not specified)
            assertEquals(1433l, niaLocation.getSceneStation().getCodeValue());
            assertEquals(1433l, fieldReport.getSceneStation().getCodeValue());
        }
        
        // if the JSON has a country then we're a foreign location
        else if (location.getCountry() != null) {
            assertEquals(location.getCountry().getCodeValue().longValue(), niaLocation.getCountry().getCodeValue());
            assertEquals(location.getTown(), niaLocation.getTown());
            verifyLocationFields(niaLocation, location);
            
            // foreign locations default to this scene station (overseas) - but it's only set on the noting - foreign locations themselves don't have scene stations
            assertEquals(1585l, fieldReport.getSceneStation().getCodeValue());
        }
             
        else {
            fail("Invalid record location");
        }
        
        assertNotNull(recordLocation.getLocationDetail());
        
    }
    
    /**
     * Verifies fields in the new NIA location were set correctly
     * 
     * @param niaLocation
     * @param location
     */
    private void verifyLocationFields(Location niaLocation, nz.govt.police.mobility.onlinereports.om.Location location) {
        String onlineReportUnitNumber = location.getUnitNumber();
        assertEquals(onlineReportUnitNumber, niaLocation.getUnitNo());

        nz.govt.police.mobility.onlinereports.om.CodedValue onlineReportUnitType = location.getUnitType();
        if (location.getUnitType() != null) {
            assertEquals(onlineReportUnitType.getCodeValue().longValue(), niaLocation.getUnitType().getCodeValue());
        }

        // Defaulted to flat if unit type is not provided and unit number is provided in the online form
        if (onlineReportUnitType == null && StringUtils.isNotBlank(onlineReportUnitNumber)) {
            assertEquals(niaLocation.getUnitType().getCodeValue(), CT_UNIT_TYPE_FLAT_CODE_VALUE);
        }
        
        assertEquals(location.getStreetNumber(), niaLocation.getStreetNumber());
        assertEquals(location.getStreetName(), niaLocation.getStreetName());
        
        if (location.getStreetType() != null) {
            assertEquals(location.getStreetType().getCodeValue().longValue(), niaLocation.getStreetType().getCodeValue());
        }

        if (location.getStreetDirection() != null) {
            assertEquals(location.getStreetDirection().getCodeValue().longValue(), niaLocation.getStreetDirection().getCodeValue());
        }

        
    }
    
    /**
     * Verifies the report data was correctly saved into the mobility field report
     * 
     * @param fieldReport
     * @param onlineReport
     */
    private void verifyReport(FieldReport fieldReport, OnlineReport onlineReport) {
        Report report = onlineReport.getReport();
        
        assertEquals(report.getStartDate(), DATE_FORMATTER.format(fieldReport.getStartDate()));
        assertEquals(report.getStartTime(), TIME_FORMATTER.format(fieldReport.getStartTime()));
        
        if (report.getEndDate() != null) {
            assertEquals(report.getEndDate(), DATE_FORMATTER.format(fieldReport.getEndDate()));
        }
        if (report.getEndTime() != null) {
            assertEquals(report.getEndTime(), TIME_FORMATTER.format(fieldReport.getEndTime()));
        }
        
        assertEquals(report.getReportedDate(), DATE_FORMATTER.format(fieldReport.getReportedDate()));
        assertEquals(report.getReportedTime(), TIME_FORMATTER.format(fieldReport.getReportedTime()));
        
        assertEquals(report.getPriority().getCodeValue().longValue(), fieldReport.getFmcPriority().getCodeValue());
        assertEquals(report.getProximity().getCodeValue().longValue(), fieldReport.getLocationProximity().getCodeValue());
        assertEquals(report.getNarrative(), fieldReport.getNarrative().toString());
        assertEquals(report.getReportId(), fieldReport.getExternalReference());
    }    

    /**
     * Verifies the PDF copy was correctly created as a Mobility attachment
     * 
     * @param fieldReport
     * @param onlineReport
     */
    private void verifyPdfCopy(FieldReport fieldReport, OnlineReport onlineReport) {
        var reportAttachment = attachmentService.retrieveAllAttachmentsForRecord(fieldReport.getActivityObjectId(), Long.valueOf(OTC_RECORD), Long.valueOf(ATTACHMENT_TYPE_ONLINE_REPORT));
        assertEquals(1, reportAttachment.size());
        MobilityAttachment originalPdf = reportAttachment.get(0);
        assertArrayEquals(onlineReport.getOriginalPdf().getData(), originalPdf.getAttachmentData());
        
        // the gateway hardcodes the description for the PDF copy
        assertEquals("105 Online Report", originalPdf.getAttachmentDescription());
        
        // the gateway uses the report ID as the filename for the PDF copy
        assertEquals("O:\\OnlineReport-" + onlineReport.getReport().getReportId() + ".pdf", originalPdf.getAttachmentFilename()); 
    }
    
    /**
     * Verifies that any attachments to the OnlineReport were saved to the Mobility database as attachments
     * 
     * @param fieldReport
     * @param onlineReport
     */
    private void verifyAttachments(FieldReport fieldReport, OnlineReport onlineReport) {
        var otherAttachments = attachmentService.retrieveAllAttachmentsForRecord(fieldReport.getActivityObjectId(), Long.valueOf(OTC_RECORD), Long.valueOf(ATTACHMENT_TYPE_ONLINE_ATTACHMENT));
        assertEquals(Optional.ofNullable(onlineReport.getAttachments()).orElseGet(Collections::emptyList).size(), otherAttachments.size());

        for (Attachment attachment : Optional.ofNullable(onlineReport.getAttachments()).orElseGet(Collections::emptyList)) {
            boolean found = false;
            for (MobilityAttachment mobilityAttachment : otherAttachments) {
                if (mobilityAttachment.getAttachmentDescription().equals(attachment.getDescription())) {
                    assertArrayEquals(attachment.getData(), mobilityAttachment.getAttachmentData());
                    assertEquals("O:\\" + attachment.getFilename(), mobilityAttachment.getAttachmentFilename()); // the gateway adds "O:\" to the start of all attachment names
                    found = true;
                }
            }
            assertTrue("Attachment not found in mobility", found);
        }
        
    }
    
}