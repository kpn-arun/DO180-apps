package nz.govt.police.mobility.onlinereports.validation;

import org.apache.commons.lang3.StringUtils;

import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.ApiError;

public abstract class AbstractOnlineReportValidatorTest {

    OnlineReportErrors onlineReportErrors;

    protected boolean containsError(String message, String field) {
        return containsError(message, field, null);
    }

    protected boolean containsError(String message, String field, String originalValue) {
        for (ApiError apiError : onlineReportErrors.toApiErrors()) {
            if (originalValue == null) {
                if (StringUtils.equals(apiError.getField(), field) && StringUtils.equals(apiError.getMessage(), message)) {
                    return true;
                }
            } else {
                if (StringUtils.equals(apiError.getField(), field) && StringUtils.equals(apiError.getMessage(), message)
                        && StringUtils.equals(apiError.getOriginalValue(), originalValue)) {
                    return true;
                }
            }
        }

        return false;
    }

}
