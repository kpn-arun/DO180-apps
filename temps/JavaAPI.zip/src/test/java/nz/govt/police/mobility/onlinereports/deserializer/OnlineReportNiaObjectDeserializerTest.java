package nz.govt.police.mobility.onlinereports.deserializer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import nz.govt.police.NIA.Common.ApplicationConstants;
import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Person;
import nz.govt.police.mobility.onlinereports.om.Vehicle;

public class OnlineReportNiaObjectDeserializerTest extends BaseOnlineReportsTest {

	private ObjectMapper objectMapper;
	
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Before
	public void setup() throws Exception {
		SimpleModule module = new SimpleModule();
		module.addDeserializer(NiaObject.class, new NiaObjectJsonDeserializer());
		objectMapper = new ObjectMapper().registerModules(module);
	}

	@Test
	public void desrializeSingleLocation() throws Exception {
		OnlineReport onlineReport = deSerialize("location.json");

		validateCommonDetails(onlineReport, ApplicationConstants.OTC_LOCATION);

		// other details
		validateLocation((Location) onlineReport.getNiaObjects().get(0));
	}

	@Test
	public void desrializeSinglePerson() throws Exception {
		OnlineReport onlineReport = deSerialize("person.json");

		validateCommonDetails(onlineReport, ApplicationConstants.OTC_PERSON);

		// other details
		validatePerson((Person) onlineReport.getNiaObjects().get(0));
	}

	@Test
	public void desrializeSingleVehicle() throws Exception {
		OnlineReport onlineReport = deSerialize("vehicle.json");

		validateCommonDetails(onlineReport, ApplicationConstants.OTC_VEHICLE);

		// other details
		validateVehicle((Vehicle) onlineReport.getNiaObjects().get(0));
	}

	@Test
	public void desrializeMultipleObject() throws Exception {
		OnlineReport onlineReport = deSerialize("multiple_objects.json");

		assertEquals(onlineReport.getNiaObjects().size(), 3);

		for (NiaObject niaObject : onlineReport.getNiaObjects()) {
			if (niaObject.getObjectType().getCodeValue() == ApplicationConstants.OTC_LOCATION) {
				validateLocation((Location) niaObject);
			}

			if (niaObject.getObjectType().getCodeValue() == ApplicationConstants.OTC_PERSON) {
				validatePerson((Person) niaObject);
			}

			if (niaObject.getObjectType().getCodeValue() == ApplicationConstants.OTC_VEHICLE) {
				validateVehicle((Vehicle) niaObject);
			}
		}
	}
	
	@Test
    public void desrializeInvalidObjectType() throws Exception {
	    exceptionRule.expect(JsonMappingException.class);
	    
        deSerialize("invalid_object_type.json");        
    }
	
	@Test
    public void desrializeEmptyObjectType() throws Exception {
	    exceptionRule.expect(JsonMappingException.class);
	    
        deSerialize("empty_object_type.json");
    }

	private void validateCommonDetails(OnlineReport onlineReport, int objectType) {
		assertNotNull(onlineReport);
		assertTrue(onlineReport.getNiaObjects().size() == 1);

		NiaObject niaObject = onlineReport.getNiaObjects().get(0);

		assertEquals(niaObject.getObjectType().getCodeTableId().longValue(), 100);
		assertEquals(niaObject.getObjectType().getCodeValue().longValue(), objectType);

		// UUID
		assertEquals(niaObject.getUuid().toString(), "bfef7f1c-4221-4040-a76d-d4561291d537");

		// Object type
		if (objectType == ApplicationConstants.OTC_LOCATION) {
			assertTrue(niaObject instanceof Location);
		}

		if (objectType == ApplicationConstants.OTC_PERSON) {
			assertTrue(niaObject instanceof Person);
		}

		if (objectType == ApplicationConstants.OTC_VEHICLE) {
			assertTrue(niaObject instanceof Vehicle);
		}

		assertNotNull(onlineReport.getReport());
		assertNotNull(onlineReport.getOriginalPdf());
		assertTrue(onlineReport.getAttachments().size() > 0);
	}

	private void validateVehicle(Vehicle vehicle) {
		assertEquals(vehicle.getVehicleRegNo(), "TST123");
		assertEquals(vehicle.getType().getCodeValue().longValue(), 10);
		assertEquals(vehicle.getMake().getCodeValue().longValue(), 3);
	}

	private void validatePerson(Person person) {
		assertEquals(person.getGender().getCodeTableId().longValue(), 31);
		assertEquals(person.getGender().getCodeValue().longValue(), 3);
		assertEquals(person.getDlicno(), "MH123456");
	}

	private void validateLocation(Location location) {
		assertEquals(location.getUnitNumber(), "1B");
		assertEquals(location.getUnitType().getCodeTableId().longValue(), 182);
		assertEquals(location.getUnitType().getCodeValue().longValue(), 20);
		assertEquals(location.getStreetName(), "Chapel");
		assertEquals(location.getStreetNumber(), "153");
		assertEquals(location.getStreetType().getCodeTableId().longValue(), 185);
		assertEquals(location.getStreetType().getCodeValue().longValue(), 39);
		assertEquals(location.getStreetDirection().getCodeTableId().longValue(), 188);
		assertEquals(location.getStreetDirection().getCodeValue().longValue(), 2);
		assertEquals(location.getSuburbTown().getCodeTableId().longValue(), 301);
		assertEquals(location.getSuburbTown().getCodeValue().longValue(), 320);
	}

	private OnlineReport deSerialize(String fileName) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				this.getClass().getClassLoader().getResourceAsStream("deserialize_json/" + fileName)));
		StringBuffer sb = new StringBuffer();
		String str;
		while ((str = reader.readLine()) != null) {
			sb.append(str);
		}

		return objectMapper.readValue(sb.toString(), OnlineReport.class);
	}
}