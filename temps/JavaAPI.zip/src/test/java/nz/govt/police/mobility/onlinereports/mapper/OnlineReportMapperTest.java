package nz.govt.police.mobility.onlinereports.mapper;

import nz.govt.police.common.datatypes.NDate;
import nz.govt.police.common.datatypes.NTime;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.common.xml.client.codeTables.LoadCodeTable.CodeTableDetails;
import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.Enums;
import nz.govt.police.mobility.service.om.FieldReport;
import nz.govt.police.mobility.service.om.Narrative;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportCreateService;
import nz.govt.police.service.impl.CodeTableService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class OnlineReportMapperTest extends BaseOnlineReportsTest {

    OnlineReportMapper objectToTest;

    @Mock
    OnlineReportCreateService createService;

    @Mock
    OnlineReportCodedValueMapper codedValueMapper;

    @Mock
    FieldReport fieldReport;

    Report data;

    @Before
    public void setup() {
        initMocks(this);
        objectToTest = new OnlineReportMapper();

        when(createService.createNewOnlineReport()).thenReturn(fieldReport);

        objectToTest.codedValueMapper = codedValueMapper;
        objectToTest.createService = createService;
        data = createOnlineReport().getReport();
    }

    @Test
    public void mapReport_success_request() throws Exception {

        when(fieldReport.isFieldReport()).thenReturn(true);
        when(fieldReport.getWorkflowStatus()).thenReturn(Enums.WorkflowStatus.INCOMPLETE);

        NDate nowDate = NDateUtil.dateNow();
        NTime nowTime = NDateUtil.timeNow();

        when(fieldReport.getStartDate()).thenReturn(nowDate);
        when(fieldReport.getStartTime()).thenReturn(nowTime);

        when(fieldReport.getReportedDate()).thenReturn(nowDate);
        when(fieldReport.getReportedTime()).thenReturn(nowTime);

        when(fieldReport.getExternalReference()).thenReturn("SZ-20200106");
        Narrative narrative = new Narrative();
        narrative.setNarrative("some narrative");

        when(fieldReport.getNarrative()).thenReturn(narrative);

        // dont know why this is not working, to be picked up later.
        // when(codedValueMapper.mapCodedValue(Mockito.anyLong(),Mockito.any(CodedValue.class))).thenReturn(any());

        FieldReport result = objectToTest.mapReport(data);

        Assert.assertEquals("SZ-20200106", result.getExternalReference());
        Assert.assertEquals("some narrative", result.getNarrative().toString());

        Assert.assertEquals(nowDate, result.getStartDate());
        Assert.assertEquals(nowTime, result.getStartTime());
    }
}