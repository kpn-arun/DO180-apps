package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.AbstractReportService.TIME_FORMAT;
import static nz.govt.police.service.NiaObjectConstants.CV_SCENE_STATION_NOT_SPECIFIED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.om.Narrative;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportCreateService;
import nz.govt.police.service.NiaObjectConstants;

public class OnlineReportCovid19AlertNotingsMapperTest extends BaseOnlineReportsTest {

    OnlineReportCovid19NotingMapper objectToTest;

    @Mock
    OnlineReportCreateService createService;

    @Mock
    OnlineReportCodedValueMapper codedValueMapper;

    @Mock
    Noting noting;

    Report data;

    @Before
    public void setup() {
        initMocks(this);
        objectToTest = new OnlineReportCovid19NotingMapper();

        when(createService.createNotingWithDefaults()).thenReturn(noting);

        objectToTest.codedValueMapper = codedValueMapper;
        objectToTest.createService = createService;
        data = createOnlineReport().getReport();
    }

    @Test
    public void mapReport_success_request() throws Exception {
        when(noting.getStartDate()).thenReturn((someDate));
        when(noting.getStartTime()).thenReturn((someTime));
        when(noting.getExternalReference()).thenReturn(data.getReportId());
        when(noting.getNarrative()).thenReturn(new Narrative("some narrative"));
        when(noting.getReference()).thenReturn(OnlineReportCovid19NotingMapper.COVID_19_ALERT_REFERENCE);
        when(noting.getDescription()).thenReturn(OnlineReportCovid19NotingMapper.COVID_19_ALERT_DESCRIPTION);
        when(noting.getSubject()).thenReturn("#" + OnlineReportCovid19NotingMapper.COVID_19_ALERT_DESCRIPTION);
        when(noting.getSceneStation()).thenReturn(CV_SCENE_STATION_NOT_SPECIFIED);
        when(noting.getNotingCategory()).thenReturn(NiaObjectConstants.CV_RECORD_TYPE_NOTING);
        when(noting.getNotingType())
                .thenReturn(new NCodedValue(CodeTableConstants.CT_RECORD_SUB_CATEGORY, OnlineReportCovid19NotingMapper.RECORD_SUB_CATEGORY_OTHER_INFORMATON));
        when(noting.getReportingStation())
                .thenReturn(new NCodedValue(CodeTableConstants.CT_ASSIGNMENT_STATION, OnlineReportCovid19NotingMapper.ASSIGNMENT_STATION_PNHQ));
        when(noting.getReportingChannel())
                .thenReturn(new NCodedValue(CodeTableConstants.CT_REPORTING_CHANNEL, OnlineReportCovid19NotingMapper.REPORTING_CHANNEL_EMAIL));
        when(noting.getSourceReliability())
                .thenReturn(new NCodedValue(CodeTableConstants.CT_SOURCE_RELIABILITY, OnlineReportCovid19NotingMapper.RELIABILITY_COMPLETE));
        when(noting.getInformationReliability())
                .thenReturn(new NCodedValue(CodeTableConstants.CT_SOURCE_RELIABILITY, OnlineReportCovid19NotingMapper.RELIABILITY_COMPLETE));
        when(noting.getFmcPriority()).thenReturn(new NCodedValue(data.getPriority().getCodeTableId(), Long.toString(data.getPriority().getCodeValue())));
        when(noting.getLocationProximity())
                .thenReturn(new NCodedValue(data.getProximity().getCodeTableId(), Long.toString(data.getProximity().getCodeValue())));

        Noting noting = objectToTest.mapNoting(data);

        assertEquals("SZ-20200106", noting.getExternalReference());
        assertEquals("some narrative", noting.getNarrative().toString());

        assertEquals(someDate, noting.getStartDate());
        assertEquals(someTime, noting.getStartTime());

        assertEquals(OnlineReportCovid19NotingMapper.COVID_19_ALERT_REFERENCE, noting.getReference());
        assertEquals(OnlineReportCovid19NotingMapper.COVID_19_ALERT_DESCRIPTION, noting.getDescription());
        assertEquals("#" + OnlineReportCovid19NotingMapper.COVID_19_ALERT_DESCRIPTION, noting.getSubject());
        assertEquals(CV_SCENE_STATION_NOT_SPECIFIED, noting.getSceneStation());
        assertEquals(NiaObjectConstants.CV_RECORD_TYPE_NOTING, noting.getNotingCategory());
        assertCodeTable(noting.getNotingType(), CodeTableConstants.CT_RECORD_SUB_CATEGORY,
                OnlineReportCovid19NotingMapper.RECORD_SUB_CATEGORY_OTHER_INFORMATON);
        assertCodeTable(noting.getReportingStation(), CodeTableConstants.CT_ASSIGNMENT_STATION, OnlineReportCovid19NotingMapper.ASSIGNMENT_STATION_PNHQ);
        assertCodeTable(noting.getReportingChannel(), CodeTableConstants.CT_REPORTING_CHANNEL, OnlineReportCovid19NotingMapper.REPORTING_CHANNEL_EMAIL);
        assertCodeTable(noting.getSourceReliability(), CodeTableConstants.CT_SOURCE_RELIABILITY, OnlineReportCovid19NotingMapper.RELIABILITY_COMPLETE);
        assertCodeTable(noting.getInformationReliability(), CodeTableConstants.CT_SOURCE_RELIABILITY, OnlineReportCovid19NotingMapper.RELIABILITY_COMPLETE);
        assertCodeTable(noting.getFmcPriority(), 2759, 2);
        assertCodeTable(noting.getLocationProximity(), 2030, 1);
    }

    private void assertCodeTable(ICodedValue actualValue, long codeTableId, long codedValue) {
        assertNotNull(actualValue);
        assertEquals(actualValue.getTableId(), codeTableId);
        assertEquals(actualValue.getCodeValue(), codedValue);
    }
}