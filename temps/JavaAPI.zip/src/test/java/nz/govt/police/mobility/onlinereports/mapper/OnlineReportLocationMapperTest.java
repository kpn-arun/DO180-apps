package nz.govt.police.mobility.onlinereports.mapper;

import static nz.govt.police.NIA.Common.ApplicationConstants.LOCATION_CAT_FOREIGN;
import static nz.govt.police.NIA.Common.ApplicationConstants.LOCATION_CAT_FULL;
import static nz.govt.police.NIA.Common.CodeTableConstants.CT_LOCN_AIW_ST_DIR_SUFF;
import static nz.govt.police.NIA.Common.CodeTableConstants.CT_LOCN_STREET_TYPE;
import static nz.govt.police.NIA.Common.CodeTableConstants.CT_LOCN_UNIT_TYPE;
import static nz.govt.police.NIA.Common.CodeTableConstants.CT_SCENE_STATION;
import static nz.govt.police.service.NiaObjectConstants.CV_SCENE_STATION_NOT_SPECIFIED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NCodedValue;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.context.OnlineReportsApplicationConfiguration;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.service.om.ActivityLocation;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.mobility.service.onduty.impl.BaseLocationService;
import nz.govt.police.nia.location.service.client.ILocationServiceClient;
import nz.govt.police.service.NiaObjectConstants;
import nz.govt.police.service.entities.nia.location.Location;

public class OnlineReportLocationMapperTest {

	@Mock
	private Noting noting;

	@Mock
	private Location locationForFormatter;
	
	@Mock
    private BaseLocationService locationService;

    @Mock
    private ILocationServiceClient locationServiceClient;       
	
	@Mock
	OnlineReportsApplicationConfiguration applicationConfiguration;
	
	@Mock
	nz.govt.police.mobility.onlinereports.om.Location incomingLocation;
	
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();	
    
    /**
     * Class under test
     */
    @InjectMocks
    private OnlineReportLocationMapper locationMapper;

    @Before
    public void setup() throws Exception {
        initMocks(this);
        
        // want a real coded value mapper to map coded values when mapping the location
        locationMapper.codedValueMapper = new OnlineReportCodedValueMapper();
		
        when(locationServiceClient.formatLocation(Mockito.anyString(), Mockito.any())).thenReturn(locationForFormatter);
        when(locationForFormatter.getLocationDetail()).thenReturn("TEST FORMATTED LOCATION");
        when(applicationConfiguration.getLocationServiceUrl()).thenReturn("Test.html");
        
    }

    /**
     * Test for adding a NIA location to the Activity when an Id is present on the incoming NIA object.
     * 
     * @throws OnlineReportException
     */
    @Test
    public void testNiaLocationInNiaObject() throws OnlineReportException {
        Mockito.when(incomingLocation.getNiaLocationId()).thenReturn(123l);
        ActivityLocation  activityLocation = new ActivityLocation();
        activityLocation.setLocation(new Location());
        Mockito.when(locationService.addQueriedLocationToNotingAsRecordLocation(123L, noting)).thenReturn(activityLocation);

        locationMapper.mapRecordLocation(incomingLocation, noting);

        Mockito.verify(locationService).addQueriedLocationToNotingAsRecordLocation(Mockito.anyLong(), Mockito.any(Noting.class));

    }
    

    /**
     * Test for adding a new location
     * 
     * @throws OnlineReportException
     */
    @Test
    public void testNewLocation() throws OnlineReportException {
    	nz.govt.police.mobility.onlinereports.om.Location jsonLocation = nz.govt.police.mobility.onlinereports.om.Location.builder()
        		.suburbTown(CodedValue.builder().codeValue(234l).codeTableId((long) CodeTableConstants.CT_TOWN_SUBURB).build())
    			.unitNumber("4")
    			.unitType(CodedValue.builder().codeValue(15l).codeTableId((long) CT_LOCN_UNIT_TYPE).build())
    			.streetNumber("5")
    			.streetName("TEST STREET")
    			.streetType(CodedValue.builder().codeValue(19l).codeTableId((long) CT_LOCN_STREET_TYPE).build())
    			.streetDirection(CodedValue.builder().codeValue(27l).codeTableId((long) CT_LOCN_AIW_ST_DIR_SUFF).build())
        		.build();
        
        Location location = locationMapper.setupNewLocation(jsonLocation);
        assertEquals("TEST FORMATTED LOCATION", location.getLocationDetail());
        assertEquals(jsonLocation.getSuburbTown().getCodeValue().longValue(), location.getTownSuburb().getCodeValue());
        assertEquals(CV_SCENE_STATION_NOT_SPECIFIED, location.getSceneStation());
        assertEquals(LOCATION_CAT_FULL, location.getCategory().getCodeValue());
        verifyFields(jsonLocation, location);
    }
    
    /**
     * Test for adding a foreign location
     * 
     * @throws OnlineReportException
     */
    @Test
    public void testForeignLocation() throws OnlineReportException {
    	nz.govt.police.mobility.onlinereports.om.Location jsonLocation = nz.govt.police.mobility.onlinereports.om.Location.builder()
    			.country(CodedValue.builder().codeValue(12l).codeTableId((long) CodeTableConstants.CT_PLACE_OF_BIRTH_COUNTRY).build())
    			.unitNumber("4")
    			.unitType(CodedValue.builder().codeValue(15l).codeTableId((long) CT_LOCN_UNIT_TYPE).build())
    			.streetNumber("5")
    			.streetName("TEST STREET")
    			.streetType(CodedValue.builder().codeValue(19l).codeTableId((long) CT_LOCN_STREET_TYPE).build())
    			.streetDirection(CodedValue.builder().codeValue(27l).codeTableId((long) CT_LOCN_AIW_ST_DIR_SUFF).build())
    			.build();

        
        Location location = locationMapper.setupNewLocation(jsonLocation);
        assertEquals("TEST FORMATTED LOCATION", location.getLocationDetail());
        assertEquals(jsonLocation.getCountry().getCodeValue().longValue(), location.getCountry().getCodeValue());
        assertEquals(LOCATION_CAT_FOREIGN, location.getCategory().getCodeValue());
        verifyFields(jsonLocation, location);
    }  
    
    @Test
    public void testSceneStationForNewLocation() throws OnlineReportException {
        nz.govt.police.mobility.onlinereports.om.Location jsonLocation = nz.govt.police.mobility.onlinereports.om.Location.builder()
                .suburbTown(CodedValue.builder().codeValue(234l).codeTableId((long) CodeTableConstants.CT_TOWN_SUBURB).build()).unitNumber("4")
                .unitType(CodedValue.builder().codeValue(15l).codeTableId((long) CT_LOCN_UNIT_TYPE).build()).streetNumber("5").streetName("TEST STREET")
                .streetType(CodedValue.builder().codeValue(19l).codeTableId((long) CT_LOCN_STREET_TYPE).build())
                .streetDirection(CodedValue.builder().codeValue(27l).codeTableId((long) CT_LOCN_AIW_ST_DIR_SUFF).build()).build();
        
        // Defaulted scene station in OnlineReportMapper
        noting.setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);

        locationMapper.mapRecordLocation(jsonLocation, noting);

        verify(noting).setSceneStation(CV_SCENE_STATION_NOT_SPECIFIED);
    }

    @Test
    public void testSceneStationForForeignLocation() throws OnlineReportException {
        nz.govt.police.mobility.onlinereports.om.Location jsonLocation = nz.govt.police.mobility.onlinereports.om.Location.builder()
                .country(CodedValue.builder().codeValue(12l).codeTableId((long) CodeTableConstants.CT_PLACE_OF_BIRTH_COUNTRY).build()).unitNumber("4")
                .unitType(CodedValue.builder().codeValue(15l).codeTableId((long) CT_LOCN_UNIT_TYPE).build()).streetNumber("5").streetName("TEST STREET")
                .streetType(CodedValue.builder().codeValue(19l).codeTableId((long) CT_LOCN_STREET_TYPE).build())
                .streetDirection(CodedValue.builder().codeValue(27l).codeTableId((long) CT_LOCN_AIW_ST_DIR_SUFF).build()).build();

        locationMapper.mapRecordLocation(jsonLocation, noting);

        verify(noting).setSceneStation(new NCodedValue(CT_SCENE_STATION, 1585));
    }
    
    private void verifyFields(nz.govt.police.mobility.onlinereports.om.Location jsonLocation, Location location) {
    	assertEquals(jsonLocation.getUnitNumber(), location.getUnitNo());
    	assertEquals(jsonLocation.getUnitType().getCodeValue().longValue(), location.getUnitType().getCodeValue());
    	assertEquals(jsonLocation.getStreetNumber(), location.getStreetNumber());
    	assertEquals(jsonLocation.getStreetName(), location.getStreetName());
    	assertEquals(jsonLocation.getStreetType().getCodeValue().longValue(), location.getStreetType().getCodeValue());
    	assertEquals(jsonLocation.getStreetDirection().getCodeValue().longValue(), location.getStreetDirection().getCodeValue());
    }

}
