package nz.govt.police.mobility.onlinereports.it;

import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.TIME_FORMAT;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.junit.BeforeClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Base test class with a bunch of annotations and a fix to stop annoying warning messages in the logs
 * 
 * @author shce24
 *
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = ScopeConfiguration.class)
@AutoConfigureMockMvc
@ActiveProfiles("auto1")
public abstract class BaseOnlineReportsTest extends BaseKeycloakTest {
    
    @Autowired
    protected ObjectMapper objectMapper;
    
	
	@Value("${spring.datasource.jndi-name}")
    protected String jndiName;

    @Autowired
    protected TestRestTemplate restTemplate;
    
    public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT);
    public static final SimpleDateFormat TIME_FORMATTER = new SimpleDateFormat(TIME_FORMAT);    

    /**
     * We put the loaded JSON report as String in here so tests can parse the JSON as an OnlineReport and interrogate the data in it
     */
    protected String reportAsString;
    
    @BeforeClass
    public static void setUp() {
        // fix for warning "Using deprecated META-INF/services mechanism with non-standard property: javax.xml.soap.MetaFactory. Property javax.xml.soap.SAAJMetaFactory should be used instead." 
        // as per https://github.com/javaee/metro-jax-ws/issues/1237
        System.setProperty("javax.xml.soap.SAAJMetaFactory", "com.sun.xml.messaging.saaj.soap.SAAJMetaFactoryImpl");
    }
    
    /**
     * Loads the supplied file from the disc and POSTs it to the gateway
     * 
     * @param file
     * @return
     * @throws IOException
     */
    protected ResponseEntity<String> submitJson(File file) throws IOException { 
    	return submitJson(FileUtils.readFileToString(file, "UTF-8"));
    }
    
    protected ResponseEntity<String> submitJson(String request) throws IOException {
    	reportAsString = request;
    	
    	var headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());
        
        HttpEntity<String> entity = new HttpEntity<String>(request, headers);

        return restTemplate.exchange("/api/report", POST, entity, String.class);
    }
    
}
