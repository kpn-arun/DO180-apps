package nz.govt.police.mobility.onlinereports.mapper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.mobility.onlinereports.om.CodedValue;

public class OnlineReportCodedValueMapperTest {

	private OnlineReportCodedValueMapper objectToTest;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@Before
	public void setUp() throws Exception {
		// no mocking needed. Use real object
		objectToTest = new OnlineReportCodedValueMapper();
	}

	@Test
	public void testMandatoryCodedValueSuccess() throws Exception {
		ICodedValue codedValue = objectToTest.mapCodedValue(CodedValue.builder().codeTableId(1L).codeValue(1L).build(),
				false);
		Assert.assertNotNull(codedValue);
		Assert.assertEquals(codedValue.getTableId(), 1);
		Assert.assertEquals(codedValue.getCodeValue(), 1);
	}

	@Test
	public void testMandatoryCodedValueFailure() throws Exception {
		expectedEx.expect(NullPointerException.class);
		objectToTest.mapCodedValue(CodedValue.builder().build(), false);
	}

	@Test
	public void testNullableCodedValueSuccessNullReturn() throws Exception {
		ICodedValue codedValue = objectToTest.mapCodedValue(CodedValue.builder().build(), true);
		Assert.assertNull(codedValue);
	}

	@Test
	public void testNullableCodedValueSuccessCodeReturn() throws Exception {
		ICodedValue codedValue = objectToTest.mapCodedValue(CodedValue.builder().codeTableId(1L).codeValue(1L).build(),
				false);
		Assert.assertNotNull(codedValue);
		Assert.assertEquals(codedValue.getTableId(), 1);
		Assert.assertEquals(codedValue.getCodeValue(), 1);
	}

}