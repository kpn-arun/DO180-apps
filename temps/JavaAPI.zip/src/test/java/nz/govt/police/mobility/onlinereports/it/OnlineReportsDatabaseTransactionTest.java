package nz.govt.police.mobility.onlinereports.it;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.extern.apachecommons.CommonsLog;
import nz.govt.police.NIA.base.NIATransaction;
import nz.govt.police.common.database.NDatabaseUtil;
import nz.govt.police.common.database.NParsedPreparedStatement;
import nz.govt.police.common.database.NResultSet;
import nz.govt.police.common.database.NWebTransaction;
import nz.govt.police.common.datatypes.NDateConstants;
import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.utils.NDateUtil;

/**
 * Test if transaction rollback and commit is happening as expected.
 * 
 * @author yhpw09
 *
 */
@RunWith(SpringRunner.class)
@CommonsLog
public class OnlineReportsDatabaseTransactionTest extends BaseOnlineReportsTest {

	@Test
	public void testRollbackTransaction() throws Exception {

		String externalReference = "db-transaction-test";
		IDate dateNow = NDateUtil.dateNow();
		ITime timeNow = NDateUtil.timeNow();
		
		String json = new String (Files.readAllBytes(Paths.get("src/test/resources/error_json/original_pdf_missing.json")));		
		json = modifyJsonValues(json, new SimpleDateFormat(NDateConstants.NIA_BRIDGE_WIRE_DATE).format(dateNow),
				timeNow.policeDisplayFormat(), externalReference);				
		log.info("Testing json " + json);

		ResponseEntity<String> result = submitJson(json);

		Assert.assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());

		try {
			NDatabaseUtil.setJNDIName("java:comp/env/" + jndiName);
			new NWebTransaction();
			NParsedPreparedStatement statement = null;
			final String sql = "SELECT * FROM MOBILITY.NOTING " + "WHERE " + "REPORTED_DT=:reportedDate "
					+ "AND REPORTED_TM=:reportedTime " + "AND EXTERNAL_REFERENCE=:externalReference";

			statement = NParsedPreparedStatement.prepareStatement(NIATransaction.currentConnection(), sql);

			statement.setDate("reportedDate", NDateUtil.asSqlDate(dateNow));
			statement.setTime("reportedTime", NDateUtil.asSqlTime(timeNow));
			statement.setString("externalReference", externalReference);

			NResultSet rs = statement.executeQuery();

			Assert.assertFalse(rs.next());
		} catch (Exception ex) {
			log.error(ex);
			Assert.fail(ex.getMessage());
		}
	}
	
	@Test
	public void testCommitTransaction() throws Exception {

		String externalReference = "db-transaction-test";
		IDate dateNow = NDateUtil.dateNow();
		ITime timeNow = NDateUtil.timeNow();

		String json = new String (Files.readAllBytes(Paths.get("src/test/resources/success_json/new_location.json")));		
		json = modifyJsonValues(json, new SimpleDateFormat(NDateConstants.NIA_BRIDGE_WIRE_DATE).format(dateNow),
				timeNow.policeDisplayFormat(), externalReference);
		log.info("Testing json " + json);

		ResponseEntity<String> result = submitJson(json);

		Assert.assertEquals(HttpStatus.OK, result.getStatusCode());

		try {
			NDatabaseUtil.setJNDIName("java:comp/env/" + jndiName);
			new NWebTransaction();
			NParsedPreparedStatement statement = null;
			final String sql = "SELECT * FROM MOBILITY.NOTING " + "WHERE " + "REPORTED_DT=:reportedDate "
					+ "AND REPORTED_TM=:reportedTime " + "AND EXTERNAL_REFERENCE=:externalReference";

			statement = NParsedPreparedStatement.prepareStatement(NIATransaction.currentConnection(), sql);

			statement.setDate("reportedDate", NDateUtil.asSqlDate(dateNow));
			statement.setTime("reportedTime", NDateUtil.asSqlTime(timeNow));
			statement.setString("externalReference", externalReference);

			NResultSet rs = statement.executeQuery();

			Assert.assertTrue(rs.next());
		} catch (Exception ex) {
			log.error(ex);
			Assert.fail(ex.getMessage());
		}
	}

	/**
	 * Ideally we would look at the field and change its value. Doing this for now for the sake of simplicity
	 */
	private String modifyJsonValues(String originalJson, String date, String time, String externalReference) {
		originalJson = originalJson.replaceAll("2019-12-10", date);
		originalJson = originalJson.replaceAll("02:32:39", time);
		originalJson = originalJson.replaceAll("SZ-20200106", externalReference);
		
		return originalJson;
    }	
}