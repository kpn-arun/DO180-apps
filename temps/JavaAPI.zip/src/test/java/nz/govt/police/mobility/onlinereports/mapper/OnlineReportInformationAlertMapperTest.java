package nz.govt.police.mobility.onlinereports.mapper;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.service.impl.InformationAlertService;
import nz.govt.police.mobility.service.om.ActivityInformationAlert;
import nz.govt.police.mobility.service.om.ActivityPerson;
import nz.govt.police.mobility.service.om.Noting;
import nz.govt.police.service.nia.om.InformationAlert;

public class OnlineReportInformationAlertMapperTest extends BaseOnlineReportsTest {

    OnlineReportInformationAlertMapper objectToTest;

    @Mock
    InformationAlertService informationAlertService;

    @Mock
    Noting noting;

    @Mock
    ActivityPerson activityObject;

    @Before
    public void setup() {
        initMocks(this);
        objectToTest = new OnlineReportInformationAlertMapper();
        objectToTest.informationAlertService = informationAlertService;
    }

    @Test
    public void testInformationAlerts() throws Exception {
        when(noting.getStartDate()).thenReturn(someDate);
        when(noting.getStartTime()).thenReturn(someTime);
        UUID uuid = UUID.randomUUID();
        when(noting.getActivityObjectUuid()).thenReturn(uuid);
        when(noting.getActivityId()).thenReturn(1l);
        when(activityObject.getActivityObjectUuid()).thenReturn(uuid);
        when(noting.getActivityObjectId()).thenReturn(1l);

        ActivityInformationAlert activityInfoAlert = objectToTest.mapInformationAlert(noting, activityObject);

        InformationAlert informationAlert = activityInfoAlert.getInformationAlert();
        assertEquals(informationAlert.getCategory().getCodeValue(), OnlineReportInformationAlertMapper.INFORMATION_ALERT_CATEGORY_PERSON);
        assertEquals(informationAlert.getNarrative(), OnlineReportInformationAlertMapper.NARRATIVE_PERSON);
        assertEquals(informationAlert.getStartDate(), someDate);
        assertEquals(informationAlert.getStartTime(), someTime);
        assertEquals(informationAlert.getExpiryDate(), NDateUtil.addMonths(someDate, OnlineReportInformationAlertMapper.EXPIRY_3_MONTHS));
        assertEquals(activityInfoAlert.getActivityId().longValue(), 1l);
        assertEquals(activityInfoAlert.getNotingUuid(), uuid);
        assertEquals(activityInfoAlert.getTargetActivityObjectUuid(), uuid);

    }
}