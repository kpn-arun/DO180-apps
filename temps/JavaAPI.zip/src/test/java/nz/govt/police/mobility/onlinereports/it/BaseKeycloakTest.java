package nz.govt.police.mobility.onlinereports.it;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.extern.apachecommons.CommonsLog;

/**
 * Deals with keycloak authentication so we can connect to the gateway
 * 
 * @author shce24
 *
 */
@CommonsLog
public abstract class BaseKeycloakTest {

    private final String AUTH_SERVER_URI = "https://keycloak.st.icpapps.preprod.govt.nz/auth/realms/POLICE/protocol/openid-connect/token";

    public String getAccessToken() {

        var restTemplate = new RestTemplate();
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        var map = new LinkedMultiValueMap<>();
        map.add("grant_type", "client_credentials");
        map.add("client_id", "onlinereports-gateway");
        map.add("client_secret", "a9d1e212-4d14-489d-923e-ebd533af2d25");
        var token = restTemplate.postForObject(AUTH_SERVER_URI, new HttpEntity<>(map, headers), KeyCloakToken.class);

        assert token != null;
        log.info("Keycloak token successfully obtained");
        return token.getAccessToken();
    }

    private static class KeyCloakToken {

        private String accessToken;

        @JsonCreator
        KeyCloakToken(@JsonProperty("access_token") final String accessToken) {
            this.accessToken = accessToken;
        }

        public String getAccessToken() {
            return accessToken;
        }
    }
}
