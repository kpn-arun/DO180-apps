package nz.govt.police.mobility.onlinereports.it;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestContextManager;

import lombok.extern.apachecommons.CommonsLog;

/**
 * Base test for running a bunch of json samples as individual junit tests
 * 
 * @author shce24
 *
 */
@CommonsLog
public abstract class OnlineReportsMultiTest extends BaseOnlineReportsTest {
    
    private File file;

    /**
     *  We need to set up the spring context manually as the test classes that extend this class use the Parameterized JUnit runner
     *  And you can't RunWith both the SpringRunner and the Parameterized runner
     *  
     */
    private TestContextManager testContextManager;
    
    public OnlineReportsMultiTest(File file) {
        this.file = file;
    }

    /**
     *  We need to set up the spring context manually as the test classes that extend this class use the Parameterized JUnit runner
     *  And you can't RunWith both the SpringRunner and the Parameterized runner
     *  
     * @throws Exception
     */
    @Before
    public void setUpContext() throws Exception {
         this.testContextManager = new TestContextManager(getClass());
         this.testContextManager.prepareTestInstance(this);
    }
    
    /**
     * Submits the JSON to the online reports gateway and validates the response
     * 
     * @param expectedResponseCode
     * @throws Exception
     */
    protected ResponseEntity<String> testJson(HttpStatus expectedResponseCode) throws Exception {
        log.info("Expecting " + expectedResponseCode + " from file " + file.getPath());
        ResponseEntity<String> response = submitJson(file);
        Assert.assertEquals(expectedResponseCode, response.getStatusCode());
        return response;
    }

    /**
     * Returns all the JSON files in the supplied directory in the format required for a Parameterized JUnit4 test (ie a collection of Object arrays)
     * 
     * @param directory
     * @return
     */
    protected static Collection<Object[]> getFiles(String directory) {
        var fileList = new ArrayList<Object[]>();
        
        for (File file : FileUtils.listFiles(new File("src/test/resources/" + directory), new String[] { "json" }, false)) {
            fileList.add(new Object[] { file });
        }
        
        return fileList;
    }
}

    

