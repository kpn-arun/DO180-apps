package nz.govt.police.mobility.onlinereports.validation;

import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.TIME_FORMAT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;

import nz.govt.police.NIA.Common.CodeTableConstants;
import nz.govt.police.common.datatypes.NDate;
import nz.govt.police.common.datatypes.NTime;
import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.common.xml.client.codeTables.LoadCodeTable.CodeTableDetails;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.service.util.IdFactory;
import nz.govt.police.service.impl.CodeTableService;

public class OnlineReportValidatorTest extends AbstractOnlineReportValidatorTest {
    
    private IDate daylightDate = new NDate(new LocalDate(2017, 9, 24).toDate().getTime());
    private ITime daylightTime = new NTime(2017, 8, 24, 2, 00, 00);

	@Mock
	private CodeTableService codeTableService;

	ReportValidator reportValidator;

	@Mock
	private Report report;

	@Before
	public void setup() throws Exception {
		initMocks(this);

		onlineReportErrors = new OnlineReportErrors();
		reportValidator = new ReportValidator();
		
		CodedValueValidator codedValidator = new CodedValueValidator();
        codedValidator.codeTableService = codeTableService;
        
        Whitebox.setInternalState(reportValidator, "codedValueValidator", codedValidator);
        
        CodeTableDetails codeTableDetails = new CodeTableDetails();
        codeTableDetails.setCodeTableId(2759L);
        codeTableDetails.setValue(2L);
        Mockito.when(codeTableService.getCode(Mockito.any(ICodedValue.class))).thenReturn(codeTableDetails); 
	}

	@Test
    public void mapReport_success() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() == 0);
    }
	
	@Test
	public void mapReport_start_date_not_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartDate()).thenReturn(null);

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);
		
		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startDate"));
	}

	@Test
	public void mapReport_invalid_start_date_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartDate()).thenReturn("invalid-format");

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startDate", "invalid-format"));
	}

	@Test
	public void mapReport_start_time_not_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartTime()).thenReturn(null);
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startTime"));
	}

	@Test
	public void mapReport_invalid_start_time_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartTime()).thenReturn("invalid-format");
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.startTime", "invalid-format"));
	}

	@Test
	public void mapReport_end_date_not_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();

		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(null);
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.endDate, report.endTime"));
	}

	@Test
	public void mapReport_report_date_not_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();

		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedDate"));

	}

	@Test
	public void mapReport_invalid_report_date_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();

		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getReportedDate()).thenReturn("invalid-format");

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedDate", "invalid-format"));

	}

	@Test
	public void mapReport_report_time_not_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndTime()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getReportedTime()).thenReturn(null);

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedTime"));
	}

	@Test
	public void mapReport_invalid_report_time_provided_in_request() throws Exception {
	    
	    mockMandatoryDetails();
	    
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndTime()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getReportedTime()).thenReturn("invalid-format");

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.reportedTime", "invalid-format"));
	}
	
	@Test
    public void mapReport_end_date_provided_without_time() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(null);

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.endDate, report.endTime"));
    }

    @Test
    public void mapReport_end_time_provided_without_date() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(null);
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.endDate, report.endTime"));
    }

    @Test
    public void mapReport_start_date_in_future() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2050-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date cannot be in the future", "report.startDate, report.startTime"));
    }

    @Test
    public void mapReport_end_date_in_future() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2050-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date cannot be in the future", "report.endDate, report.endTime"));
    }

    @Test
    public void mapReport_reported_date_in_future() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2050-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date cannot be in the future", "report.reportedDate, report.reportedTime"));
    }

    @Test
    public void mapReport_start_date_100_years_prior() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("1920-03-01", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date 100 years prior", "report.startDate"));
    }

    @Test
    public void mapReport_end_date_before_start_date() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:19:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Report end date/time must not be before report start date/time",
                "report.startDate, report.startTime, report.endDate, report.endTime"));
    }

    @Test
    public void mapReport_reported_date_before_start_date() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Report reported date/time must not be before report start date/time",
                "report.startDate, report.startTime, report.reportedDate, report.reportedTime"));
    }

    @Test
    public void mapReport_end_date_in_daylight_saving() throws Exception {

        mockMandatoryDetails();        

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2018-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(daylightDate));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(daylightTime));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-10", DATE_FORMAT)));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("02:32:39", TIME_FORMAT)));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date is in daylight savings range", "report.endDate, report.endTime"));
    }

    @Test
    public void mapReport_reported_date_in_daylight_saving() throws Exception {

        mockMandatoryDetails();

        when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2018-12-09", DATE_FORMAT)));
        when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:20:39", TIME_FORMAT)));

        when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateFromString("2019-12-09", DATE_FORMAT)));
        when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeFromString("20:30:19", TIME_FORMAT)));

        when(report.getReportedDate()).thenReturn(NDateUtil.timestampFormat(daylightDate));
        when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(daylightTime));

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError("Date is in daylight savings range", "report.reportedDate, report.reportedTime"));
    }


	@Test
	public void mapReport_external_reference_not_provided_in_request() throws Exception {
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndTime()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));
		when(report.getReportId()).thenReturn(null);

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.reportedId"));
	}

	@Test
	public void mapReport_narrative_not_provided_in_request() throws Exception {
		when(report.getStartDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getStartTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndDate()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getEndTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));

		when(report.getEndTime()).thenReturn(NDateUtil.timestampFormat(NDateUtil.dateNow()));
		when(report.getReportedTime()).thenReturn(NDateUtil.sqlTimeFormat(NDateUtil.timeNow()));
		when(report.getReportId()).thenReturn("123");

		when(report.getNarrative()).thenReturn(null);

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.narrative"));
	}
	
	@Test
	public void mapReport_no_priority_provided_in_request() throws Exception {
		when(report.getPriority()).thenReturn(null);		

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

		assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.priority"));
	}
	
	@Test
	public void mapReport_invalid_priority_provided_in_request() throws Exception {
		when(report.getPriority()).thenReturn(CodedValue.builder().build());		

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

	      assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.priority"));
	}	
	
	@Test
	public void mapReport_no_proximity_provided_in_request() throws Exception {
		when(report.getProximity()).thenReturn(null);		

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

	    assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.proximity"));
	}
	
	@Test
	public void mapReport_invalid_proximity_provided_in_request() throws Exception {
		when(report.getProximity()).thenReturn(CodedValue.builder().build());		

		reportValidator.validate(report, onlineReportErrors);

		assertTrue(onlineReportErrors.count() > 0);

	    assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "report.proximity"));
	}	

    @Test
    public void no_location_object_exception() throws Exception {
        when(report.getLocation()).thenReturn(null);       

        reportValidator.validate(report, onlineReportErrors);

        assertTrue(onlineReportErrors.count() > 0);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "report.recordLocation"));
    }
    
    @Test
    public void validateDate() throws Exception {     

        String dateNow = NDateUtil.timestampFormat(NDateUtil.dateNow());
        IDate date = reportValidator.validateDate(dateNow);

        assertEquals(dateNow, NDateUtil.timestampFormat(date));
    }
    
    @Test
    public void validateTime() throws Exception {   

        String timeNow = NDateUtil.sqlTimeFormat(NDateUtil.timeNow());
        ITime time = reportValidator.validateTime(timeNow);

        assertEquals(timeNow, NDateUtil.sqlTimeFormat(time));
    }
    
    private void mockMandatoryDetails() {
        when(report.getReportId()).thenReturn("12345");
        when(report.getNarrative()).thenReturn("test");
        when(report.getLocation()).thenReturn(IdFactory.getRandomUUID());
        when(report.getPriority()).thenReturn(CodedValue.builder().codeValue(1L).codeTableId((long) CodeTableConstants.CT_FMC_PRIORITY).build());
        when(report.getProximity()).thenReturn(CodedValue.builder().codeValue(1L).codeTableId((long) CodeTableConstants.CT_LCTN_PROXIMITY_TYPE).build());
    }
}