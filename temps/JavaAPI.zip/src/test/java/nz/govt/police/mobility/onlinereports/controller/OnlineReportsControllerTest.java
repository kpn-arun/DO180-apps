package nz.govt.police.mobility.onlinereports.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.MockitoAnnotations.initMocks;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;

import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.onlinereports.services.Covid19AlertService;
import nz.govt.police.mobility.onlinereports.services.OnlineReportService;

public class OnlineReportsControllerTest extends BaseOnlineReportsTest {

    @InjectMocks
    OnlineReportsController objectToTest;

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Mock
    OnlineReportService onlineReportService;

    @Mock
    OnlineReport onlineReport;

    @Mock
    Report report;

    @Mock
    Covid19AlertService covid19AlertService;
    
    @Before
    public void setup() {
        initMocks(this);
        objectToTest.onlineReportService = onlineReportService;
        objectToTest.covid19AlertService = covid19AlertService;
    }

    @Test
    public void addReport_success_when_online_report_provided() {
        ResponseEntity<Object> responseEntity=objectToTest.addReport(createOnlineReport());
        Assert.assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
    }

    @Test
    public void addReport_when_online_report_exception_thrown_returns_400() throws Exception {
        doThrow(new OnlineReportException("No report data found.")).when(onlineReportService).createReport(onlineReport);
        ResponseEntity<Object> result = objectToTest.addReport(onlineReport);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }
    
    @Test
    public void addReport_when_online_report_exception_thrown_returns_500() throws Exception {
        doThrow(new RuntimeException("Involved object not contained within activity object.")).when(onlineReportService).createReport(onlineReport);
        Mockito.when(onlineReport.getReport()).thenReturn(report);
        ResponseEntity<Object> result = objectToTest.addReport(onlineReport);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    }
    
    @Test
    public void addCovid_success_when_online_report_provided() {
        ResponseEntity<Object> responseEntity=objectToTest.addCovid19Alert(createOnlineReport());
        Assert.assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
    }

    @Test
    public void addCovid_when_online_report_exception_thrown_returns_400() throws Exception {
        doThrow(new OnlineReportException("No report data found.")).when(covid19AlertService).createCovid19Alert(onlineReport);
        ResponseEntity<Object> result = objectToTest.addCovid19Alert(onlineReport);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }
    
    @Test
    public void addCovid_when_online_report_exception_thrown_returns_500() throws Exception {
        doThrow(new RuntimeException("Involved object not contained within activity object.")).when(covid19AlertService).createCovid19Alert(onlineReport);
        Mockito.when(onlineReport.getReport()).thenReturn(report);
        ResponseEntity<Object> result = objectToTest.addCovid19Alert(onlineReport);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    }

    // below test needs fiddling somehow keep getting NPE where ideally Report would have populated with blank object & printed null in log line instead gives
    // NPE
    // Cant seem to figure out why.. leaving for now, come back to it later
    // This scenario can be covered in Integration test.
    /*
     * @Ignore public void addReport_when_internal_report_exception_thrown_returns_500() throws Exception{ doThrow(new
     * ArithmeticException()).when(onlineReportService).createReport(onlineReport);
     * 
     * onlineReport.setReport(report); ResponseEntity<Object> result = objectToTest.addReport(onlineReport);
     *
     * Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,result.getStatusCode()); }
     */

    @Test(expected = Test.None.class /* no exception expected */)
    public void handle() {
        objectToTest.handle(new HttpMessageNotReadableException("some error"));
    }
}