package nz.govt.police.mobility.onlinereports.it;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.io.File;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.http.ResponseEntity;

import nz.govt.police.mobility.onlinereports.om.ApiErrors;

/**
 * Runs the json samples in the error_json directory as separate junit tests
 * 
 * @author shce24
 *
 */
@RunWith(Parameterized.class)
public class OnlineReportsBadRequestJsonTest extends OnlineReportsMultiTest {
    
    public OnlineReportsBadRequestJsonTest(File file) {
        super(file);
    }
    
    @Parameters(name = "{0}")
    public static Collection<Object[]> data() {
        return getFiles("error_json");
    }
    
    /**
     * All the samples should return a 400 and a useful message
     * 
     * @throws Exception
     */
    // @105 @api_gateway
    @Test
    public void testBadRequestJson() throws Exception {
        ResponseEntity<String> response = testJson(BAD_REQUEST);
        ApiErrors apiResponse = objectMapper.readValue(response.getBody(), ApiErrors.class);
        assertEquals(BAD_REQUEST.value(), apiResponse.getStatus());
        assertNotNull(apiResponse.getMessage());
    }
    
}
