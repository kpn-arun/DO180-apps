package nz.govt.police.mobility.onlinereports.it;

import java.util.HashMap;

import org.springframework.beans.factory.config.CustomScopeConfigurer;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.SimpleThreadScope;
import org.springframework.web.context.WebApplicationContext;

/**
 * Recently we made OnlineReportsGatewayRequest request scoped. Which means parts of IT which try to use OnlineReportsGatewayRequest outside of usual web
 * request would fail. The following code fixes that.
 * 
 * @author yhpw09
 *
 */

@TestConfiguration
public class ScopeConfiguration {

    @Bean
    public CustomScopeConfigurer customScopeConfigurer() {
        CustomScopeConfigurer scopeConfigurer = new CustomScopeConfigurer();

        HashMap<String, Object> scopes = new HashMap<String, Object>();
        scopes.put(WebApplicationContext.SCOPE_REQUEST, new SimpleThreadScope());
        scopes.put(WebApplicationContext.SCOPE_SESSION, new SimpleThreadScope());
        scopeConfigurer.setScopes(scopes);

        return scopeConfigurer;
    }
}
