package nz.govt.police.mobility.onlinereports;

import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.DATE_FORMAT;
import static nz.govt.police.mobility.onlinereports.services.OnlineReportService.TIME_FORMAT;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Rule;
import org.junit.rules.ExpectedException;

import nz.govt.police.common.interfaces.IDate;
import nz.govt.police.common.interfaces.ITime;
import nz.govt.police.common.utils.NDateUtil;
import nz.govt.police.mobility.onlinereports.om.Attachment;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.mobility.onlinereports.om.NiaObject;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Report;

public abstract class BaseOnlineReportsTest {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    public static IDate someDate = NDateUtil.dateFromString("2020-01-03", DATE_FORMAT);
    public static ITime someTime = NDateUtil.timeFromString("22:10:12", TIME_FORMAT);
    public static UUID reportId= UUID.fromString("0c5310b3-c835-49ee-9784-8a2bb00e4450");

    public OnlineReport createOnlineReport() {

        String narrative = "Non-Emergency(105) Online Reporting\\r\\nYour Online Reference number is:\\t ORLH-066   \\r\\n \\r\\n\\r\\nSERVICE REQUEST DETAILS\\r\\nReported Date/Time\\t03/12/2019 15:16   \\r\\nReporting Channel\\tWeb Form \\r\\n\\r\\n\\r\\nEVENT DETAIL\\r\\nStart Date & Time\\t04/11/2019 14:58  \\r\\nEnd Date & Time\\t12/11/2019 14:58  \\r\\n \\r\\n________________________________________\\r\\nEVENT LOCATION\\r\\nLocation type\\t An organisation   \\r\\nName\\t coin raise \\r\\nAdditional Information\\t on terrace near the steps   \\r\\n \\r\\nNIA ID\\t 4491259204 \\r\\nFull Address\\t 89 ANDERSON ROAD, MATAKANA, AUCKLAND 0985 \\r\\nStreet Number\\t 89 \\r\\nStreet Name\\t ANDERSON \\r\\nStreet Type\\t Road \\r\\nTown/Suburb\\t MATAKANA  \\r\\n \\r\\nPost Code\\t 985  \\r\\n \\r\\n \\r\\nFree format address (can not find the address)\\tNo\\r\\n \\r\\nProximity\\t Outside   \\r\\nAny of stolen items taken from inside a vehicle?\\t Yes   \\r\\nLicence plate number of the vehicle?\\t jad67   \\r\\nWhere was the vehicle?\\t Parked on a road   \\r\\n________________________________________\\r\\n  EVENT NARRATIVE / CIRCUMSTANCES\\r\\nQ.Please describe what happened. Everything you tell us helps.\\r\\n parked on a road to catch up with friend AND then car was stolen   \\r\\n\\r\\nQ.Can you think of any reason why they did this?\\r\\n car is expensive and in good condition   \\r\\n\\r\\nQ.Please describe any other evidence that exists?\\r\\n left clothing   \\r\\n \\r\\n________________________________________\\r\\nWHO WAS INVOLVED?\\r\\nQ.Do you know or suspect who might have done this?\\r\\n Yes   \\r\\n \\r\\nQ.This person is a:\\r\\n A family member   \\t    \\r\\n     \\r\\nQ.Please provide as much detail about the person(s) as you can.\\r\\n jil jack, 04.09.1899, female, avalon & guy guy, 09.09.1980,male,porirua   \\r\\n \\r\\nQ.Can you describe the person(s) who did, or might have done this?\\r\\n Yes   \\r\\n \\r\\nQ.Please include age, build, clothing, distinguishing features or anything that could help us identify them.\\r\\n 67,short guy,fine, black eye   \\r\\n \\r\\nQ.Do you know if the person(s) who did this used a vehicle?\\r\\n Yes   \\r\\n \\r\\nQ.Enter the licence plate if known\\r\\n hjk98   \\r\\n \\r\\nQ.What did the vehicle look like?\\r\\n old sedan car   \\r\\n \\r\\nQ.Is there anyone we could contact who saw it happen?\\r\\n Yes   \\r\\n \\r\\nQ.Please provide their name(s) and contact details.\\r\\n jermy jackson- 092342223, jack king-00832109   \\r\\n\\r\\n________________________________________\\r\\nINFORMANT\\r\\nName\\t HANDERSON   /  fiona   /  fiona-fiona   \\r\\nDate of Birth\\t23/03/1970 \\r\\nGender\\t Gender Diverse   \\r\\nDriver Licence\\t hun123   \\r\\nAddress Type\\t Contact address   \\r\\nPrevious name (if there is)\\tNo  \\r\\nName\\t    \\r\\nAlready provided this address (same as the Location)\\t \\r\\nAddress\\r\\nNIA ID\\t 4490278592   \\t\\r\\nFull Address\\t 34 CORRICVALE WAY, NORTHCROSS, AUCKLAND 0630   \\r\\nStreet Number\\t 34   \\r\\nStreet Name\\t CORRICVALE   \\r\\nStreet Type\\t Way   \\r\\nTown/Suburb\\t NORTHCROSS   \\r\\nPost Code\\t 630   \\r\\n  \\r\\nPrefered contact method\\t Phone   \\r\\nPhone Number & type\\t+974-020-8727422343     Mobile   \\r\\n\\r\\n \\r\\nEmail Address\\t abc@abc.com   \\r\\n \\r\\n________________________________________\\r\\nREPORT ON BEHALF OF SOMEONE ELSE\\r\\nName\\t HUDSON   /  gren   \\r\\nDate of Birth/Age\\t 57   \\r\\nRelationship to Informant\\t Flatmate/boarder   \\r\\nGender\\t    \\r\\nDriver Licence\\t \\r\\nAddress\\r\\nNIA ID\\t 554610288441   \\t\\r\\nFull Address\\t 123 STAPLETONS ROAD, RICHMOND, CHRISTCHURCH CITY 8013   \\r\\nStreet Number\\t 123   \\r\\nStreet Name\\t STAPLETONS   \\r\\nStreet Type\\t Road   \\r\\nTown/Suburb\\t RICHMOND   \\r\\nPost Code\\t 8013   \\r\\n \\r\\nAddress Type\\t Contact address   \\r\\nPhone Number & type\\t+239-030-23434534     Work   \\r\\n\\r\\n \\r\\n \\r\\nEmail Address\\t abc@abc.com   \\r\\n \\r\\n________________________________________\\r\\nREPORT ON BEHALF OF ORGANISATION\\r\\nOrganisation Name\\t pluming company   \\r\\nAddress\\r\\nNIA ID\\t 4490017750   \\t\\r\\nFull Address\\t 56 DAVIS ROAD, CUST, WAIMAKARIRI DISTRICT 7471   \\r\\nStreet Number\\t 56   \\r\\nStreet Name\\t DAVIS   \\r\\nStreet Type\\t Road   \\r\\nTown/Suburb\\t CUST   \\r\\nPost Code\\t 7471   \\r\\n \\r\\nPhone Number & type\\t+599-050-2342323     Work   \\r\\n\\r\\n \\r\\n \\r\\n________________________________________\\r\\n \\r\\nStolen Vehicle\\r\\nWas a vehicle Stolen?\\t Yes   \\r\\nStolen Vehicle 1\\r\\nlicence plate details\\t jim12   \\r\\nWhere was it stolen from?\\t Parked on a road   \\r\\nWho owns it?\\t Somebody else does   \\r\\nTowing Authority\\r\\nDoes registered owner agree to towing costs?\\t Yes   \\r\\nOwner's name\\t HUDSON   /  gren   \\r\\n\\r\\n________________________________________\\r\\nStolen Item 1  \\r\\nItem Category\\t \\r\\n\\t PROPERTY   \\r\\nWhat was stolen?\\t Plumber(Tools)   \\r\\nNIA Item Classification\\t PROPERTY   > Tools, Machinery & Industrial Equipment >  >   Plumber   \\r\\nWho owns it?\\t An organisation does   \\t\\t\\r\\nOrganisation name\\t pluming company   \\r\\nSerial or ID number\\t j876nh8777   \\r\\nWhat is the value of the item?\\t$200.00 \\r\\nPlease describe it.\\t Ford, Econovan Maxi, 2002, White, Red, dusty and dirty   \\r\\n\\r\\n________________________________________\\r\\nVICTIM SUPPORT \\r\\nWould like to be contacted by Victim Support\\r\\nName\\tYes/No\\r\\n HANDERSON   /  fiona   /  fiona-fiona   \\t Yes   \\r\\n HUDSON   /  gren   \\t Yes   \\r\\n\\r\\n________________________________________\\r\\nATTACHMENTS\\r\\nDescription\\tFile Name\\r\\n 1   \\t Untitled.bmp   \\r\\n 2   \\t Untitled.gif   \\r\\n 3   \\t Untitled.png   \\r\\n \\r\\nAttachments: (Click the filename to launch)\\r\\nUntitled.png  Untitled.gif  Untitled.bmp\\r\\n\\r\\n\\r\\n\"\n"
                + "  },";

        OnlineReport onlineReport = new OnlineReport();
        Report report = new Report();

        report.setReportId("SZ-20200106");
        report.setReportUuid(reportId);
        report.setReportedDate(someDate.toString());
        report.setReportedTime(someTime.toString());
        report.setNarrative(narrative);

        CodedValue priority = new CodedValue();
        priority.setCodeTableId(2759L);
        priority.setCodeValue(2L);
        priority.setCodeDescription("P2");
        report.setPriority(priority);

        CodedValue proximity = new CodedValue();
        proximity.setCodeDescription("At");
        proximity.setCodeTableId(2030L);
        proximity.setCodeValue(1L);
        report.setProximity(proximity);

        // create location object
        Location location = new Location();

        CodedValue codedValueLoc = new CodedValue();
        codedValueLoc.setCodeTableId(100L);
        codedValueLoc.setCodeValue(4L);
        codedValueLoc.setCodeDescription("Location");

        // dont think location is needed for report mapper
        location.setObjectType(codedValueLoc);
        location.setUuid(UUID.fromString("bfef7f1c-4221-4040-a76d-d4561291d537"));
        location.setNiaLocationId(4490315122L);

        List<NiaObject> niaObjects = new ArrayList<>();
        niaObjects.add(location);

        // add all nia objects.
        onlineReport.setNiaObjects(niaObjects);

        // Attachment
        Attachment attachment = new Attachment();
        attachment.setAttachmentUuid(UUID.fromString("70989a1a-c4a2-4b10-88aa-e2ffc36084cb"));
        attachment.setData("YmxhaGJsYWg=".getBytes());
        attachment.setDescription("Something meaningful");
        attachment.setFilename("attachment1.txt");
        attachment.setContentType("image/jpg");

        List<Attachment> attachmentList = new ArrayList<>();
        attachmentList.add(attachment);
        // add attachments, say image
        onlineReport.setAttachments(attachmentList);

        // PDF
        Attachment pdf = new Attachment();
        pdf.setAttachmentUuid(UUID.fromString("95ca5568-3f06-4095-bd4e-233b25127d8d"));
        pdf.setData("YmxhaGJsYWg=".getBytes());
        pdf.setContentType("application/pdf");

        // add PDF -still of type attachment say, PDF document
        onlineReport.setOriginalPdf(pdf);

        // set location
        report.setLocation(UUID.fromString("bfef7f1c-4221-4040-a76d-d4561291d537"));

        onlineReport.setReport(report);

        return onlineReport;
    }
}
