package nz.govt.police.mobility.onlinereports.validation;

import static org.junit.Assert.assertTrue;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;

import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.xml.client.codeTables.LoadCodeTable.CodeTableDetails;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.onlinereports.om.Location;
import nz.govt.police.service.impl.CodeTableService;

public class OnlineReportLocationValidatorTest extends AbstractOnlineReportValidatorTest {

    @Mock
    private CodeTableService codeTableService;

    LocationValidator validator;

    @Before
    public void setup() throws Exception {
        initMocks(this);

        onlineReportErrors = new OnlineReportErrors();
        validator = new LocationValidator();
        
        CodedValueValidator codedValidator = new CodedValueValidator();
        codedValidator.codeTableService = codeTableService;
        
        Whitebox.setInternalState(validator, "codedValueValidator", codedValidator);
        
        CodeTableDetails codeTableDetails = new CodeTableDetails();
        codeTableDetails.setCodeTableId(2759L);
        codeTableDetails.setValue(2L);
        Mockito.when(codeTableService.getCode(Mockito.any(ICodedValue.class))).thenReturn(codeTableDetails);        
    }

    /**
     * Test for adding an invalid location
     */
    @Test
    public void testInvalidLocation() throws OnlineReportException {
        Location jsonLocation = Location.builder().build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaobject.country"));
    }

    /**
     * Test for adding a location with just nia Id
     */
    @Test
    public void testLocationWithNiaId() throws OnlineReportException {
        Location jsonLocation = Location.builder().niaLocationId(10L).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    /**
     * Test for adding a location with valid suburb town
     */
    @Test
    public void testLocationWithValidSuburbTown() throws OnlineReportException {
        Location jsonLocation = Location.builder().suburbTown(new CodedValue(301L, 320L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    /**
     * Test for adding a location with invalid country
     */
    @Test
    public void testLocationWithInValidSuburbTown() throws OnlineReportException {
        Location jsonLocation = Location.builder().suburbTown(new CodedValue(300L, 320L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaobject.suburbTown"));
    }

    /**
     * Test for adding an location with valid Country
     */
    @Test
    public void testLocationWithValidCountry() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    /**
     * Test for adding an location with invalid suburb town
     */
    @Test
    public void testLocationWithInValidCountry() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(30L, 226L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaobject.country"));
    }
    
    @Test
    public void testLocationWithValidUnitType() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).unitType(new CodedValue(182L, 1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }


    @Test
    public void testLocationWithInValidUnitType() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).unitType(new CodedValue(181L, -1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaobject.unitType"));
    }
    

    @Test
    public void testLocationWithValidStreetType() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).streetType(new CodedValue(185L, 1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    @Test
    public void testLocationWithInValidStreetType() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).streetType(new CodedValue(189L, -1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaobject.streetType"));
    }
    
    @Test
    public void testLocationWithValidStreetDirection() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).streetDirection(new CodedValue(188L, 1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    @Test
    public void testLocationWithInValidStreetDirection() throws OnlineReportException {
        Location jsonLocation = Location.builder().country(new CodedValue(3L, 226L, "test")).streetDirection(new CodedValue(186L, -1L, "test")).build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaobject.streetDirection"));
    }
    
    @Test
    public void testLocationWithoutCountryOrSuburb() throws OnlineReportException {
        Location jsonLocation = Location.builder().build();

        validator.validate(jsonLocation, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_VALUE, "niaobject.country"));
    }
    
}
