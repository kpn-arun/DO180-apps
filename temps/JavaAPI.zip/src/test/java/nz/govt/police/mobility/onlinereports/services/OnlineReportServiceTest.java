package nz.govt.police.mobility.onlinereports.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.UUID;

import org.apache.commons.lang3.SerializationUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import nz.govt.police.mobility.onlinereports.BaseOnlineReportsTest;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportAttachmentMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportLocationMapper;
import nz.govt.police.mobility.onlinereports.mapper.OnlineReportMapper;
import nz.govt.police.mobility.onlinereports.om.OnlineReport;
import nz.govt.police.mobility.onlinereports.om.Report;
import nz.govt.police.mobility.onlinereports.validation.Validation;
import nz.govt.police.mobility.service.impl.AttachmentService;
import nz.govt.police.mobility.service.impl.OutboundTriggerService;
import nz.govt.police.mobility.service.impl.reportextract.ReportingExtractService;
import nz.govt.police.mobility.service.interfaces.IWorkflowService;
import nz.govt.police.mobility.service.om.FieldReport;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportOffenceService;
import nz.govt.police.mobility.service.onduty.impl.onlinereport.OnlineReportSaveService;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SerializationUtils.class, FieldReport.class })
public class OnlineReportServiceTest extends BaseOnlineReportsTest {

    @InjectMocks
    OnlineReportService objectToTest;

    @Mock
    OnlineReportMapper reportMapper;

    @Mock
    FieldReport fieldReport;

    @Mock
    OnlineReportLocationMapper locationMapper;

    @Mock
    OnlineReportOffenceService offenceService;

    @Mock
    OnlineReportSaveService onlineReportsSaveService;

    @Mock
    IWorkflowService workflowService;

    @Mock
    AttachmentService attachmentService;

    @Mock
    OnlineReportAttachmentMapper attachmentMapper;

    @Mock
    OutboundTriggerService outboundTriggerService;

    @Mock
    OnlineReport mockReport;
    
    @Mock
    Validation validator;
    
    @Mock
    ReportingExtractService reportingExtractService;

    @Before
    public void setup() throws Exception {
        initMocks(this);
        objectToTest.reportMapper = reportMapper;
        objectToTest.locationMapper = locationMapper;
        objectToTest.offenceService = offenceService;
        objectToTest.onlineReportsSaveService = onlineReportsSaveService;
        objectToTest.workflowService = workflowService;
        objectToTest.attachmentService = attachmentService;
        objectToTest.attachmentMapper = attachmentMapper;
        objectToTest.outboundTriggerService = outboundTriggerService;
        objectToTest.validation = validator;

        when(fieldReport.getActivityObjectUuid()).thenReturn(reportId);
        when(reportMapper.mapReport(any(Report.class))).thenReturn(fieldReport);
        
        PowerMockito.mockStatic(SerializationUtils.class);
        
    }

    @Test
    public void createReport_successfully() throws Exception { 	
        UUID reportUuid=objectToTest.createReport(createOnlineReport()); // nothing to return
        assertNotNull(reportUuid);
        assertEquals(reportId,reportUuid);
    }

    @Test
    public void createReport_no_report_data_exception() throws Exception {
        expectedEx.expect(OnlineReportException.class);
        expectedEx.expectMessage("No report data found");

        objectToTest.createReport(mockReport);
    }

    @Test
    public void createReport_no_nia_objects_exception() throws Exception {
        expectedEx.expect(OnlineReportException.class);
        expectedEx.expectMessage("No NIA objects found in report: 0c5310b3-c835-49ee-9784-8a2bb00e4450");
        mockReport = createOnlineReport();
        mockReport.setNiaObjects(null);
        
		Mockito.doThrow(
				new OnlineReportException("No NIA objects found in report: " + mockReport.getReport().getReportUuid()))
				.when(validator).validate(mockReport);

        objectToTest.createReport(mockReport);
    }

    @Test
    public void createReport_no_original_pdf_exception() throws Exception {
        expectedEx.expect(OnlineReportException.class);
        expectedEx.expectMessage("No original report PDF found in report: 0c5310b3-c835-49ee-9784-8a2bb00e4450");
        mockReport = createOnlineReport();
        mockReport.setOriginalPdf(null);

        objectToTest.createReport(mockReport);
    }

}