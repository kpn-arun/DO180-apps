package nz.govt.police.mobility.onlinereports.it;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.io.File;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * Runs the json samples in the invalid_json directory as separate junit tests
 * These won't end up hitting the gateway in real life as they'll go through the datapower which will reject them there before they even hit the gateway
 * 
 * They only exist here as examples of bad json so the testers can see the difference between invalid json and json that we're rejecting with a 400
 * 
 * @author shce24
 *
 */
@RunWith(Parameterized.class)
public class OnlineReportsInvalidJsonTest extends OnlineReportsMultiTest {

    public OnlineReportsInvalidJsonTest(File file) {
        super(file);
    }
    
    @Parameters(name = "{0}")
    public static Collection<Object[]> data() {
        return getFiles("invalid_json");
    }
    
    // @105 @api_gateway
    @Test
    public void testBadRequestJson() throws Exception {
        testJson(BAD_REQUEST);
    }
    
}
