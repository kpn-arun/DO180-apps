package nz.govt.police.mobility.onlinereports.validation;

import static org.junit.Assert.assertTrue;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;

import nz.govt.police.common.interfaces.ICodedValue;
import nz.govt.police.common.xml.client.codeTables.LoadCodeTable.CodeTableDetails;
import nz.govt.police.mobility.onlinereports.OnlineReportErrors;
import nz.govt.police.mobility.onlinereports.OnlineReportException;
import nz.govt.police.mobility.onlinereports.om.CodedValue;
import nz.govt.police.mobility.onlinereports.om.Vehicle;
import nz.govt.police.service.impl.CodeTableService;

public class OnlineReportVehicleValidatorTest extends AbstractOnlineReportValidatorTest {

    @Mock
    private CodeTableService codeTableService;

    VehicleValidator vehicleValidator;

    @Before
    public void setup() throws Exception {
        initMocks(this);

        onlineReportErrors = new OnlineReportErrors();
        vehicleValidator = new VehicleValidator();

        CodedValueValidator codedValidator = new CodedValueValidator();
        codedValidator.codeTableService = codeTableService;
        
        Whitebox.setInternalState(vehicleValidator, "codedValueValidator", codedValidator);
        
        CodeTableDetails codeTableDetails = new CodeTableDetails();
        codeTableDetails.setCodeTableId(2759L);
        codeTableDetails.setValue(2L);
        Mockito.when(codeTableService.getCode(Mockito.any(ICodedValue.class))).thenReturn(codeTableDetails); 
    }

    /**
     * Test for adding an invalid vehicle
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testInvalidVehicle() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(onlineReportErrors.count() == 2);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.vehicleRgNo"));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.type"));
    }

    /**
     * Test for adding a valid rego. All rego, make and type are valid
     * @105 @api_gateway @vehicle
     */
    @Test
    public void testValidVehicle() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();
        vehicle.setVehicleRegNo("TL1123");
        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));
        vehicle.setType(new CodedValue(107L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(!onlineReportErrors.hasErrors());
    }

    /**
     * Test for adding a vehicle with in valid rego
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithInvalidRego() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();
        vehicle.setVehicleRegNo("TL112311111111"); // too long
        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));
        vehicle.setType(new CodedValue(107L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.vehicleRgNo", "TL112311111111"));
    }

    /**
     * Test for adding a vehicle with invalid make
     * @105 @api_gateway @vehicle
     */
    @Test
    public void testVehicleWithInValidMake() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        CodedValue inCorrectMake = new CodedValue(110L, 12L, "Valid TableId is 105");
        vehicle.setMake(inCorrectMake);// invalid

        vehicle.setVehicleRegNo("TL111");

        vehicle.setType(new CodedValue(107L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.make", inCorrectMake.toString()));
    }

    /**
     * Test for adding a vehicle with invalid type
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithInValidType() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        CodedValue incorrectType = new CodedValue(110L, 12L, "Valid TableId is 107");
        vehicle.setType(incorrectType); // invalid

        vehicle.setVehicleRegNo("TL111");

        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.type", incorrectType.toString()));
    }
    
    /**
     * Test for adding a vehicle with invalid identifying feautres
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithValidIdentifyingFeatures() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        vehicle.setVehicleRegNo("TL1123");
        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));
        vehicle.setType(new CodedValue(107L, 12L, "Valid TableId"));

        vehicle.setIdentifyingFeatures("Old rusty car");

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(!containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.identifyingFeatures", "Old rusty car"));
    }

    /**
     * Test for adding a vehicle with invalid identifying feautres
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithInValidIdentifyingFeatures() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        vehicle.setVehicleRegNo("TL1123");
        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));
        vehicle.setType(new CodedValue(107L, 12L, "Valid TableId"));

        StringBuilder identifyingFeaturesTooLong = new StringBuilder();
        for (int i = 0; i <= NiaObjectValidator.IDENTIFYING_FEATURES_MAX_LENGTH; i++) {
            identifyingFeaturesTooLong.append("s");
        }
        vehicle.setIdentifyingFeatures(identifyingFeaturesTooLong.toString());

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.identifyingFeatures", identifyingFeaturesTooLong.toString()));
    }

    /**
     * Test for adding a vehicle with invalid type and make
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithInValidTypeAndMake() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        CodedValue incorrectType = new CodedValue(110L, 12L, "Valid TableId is 107");
        vehicle.setType(incorrectType); // invalid

        vehicle.setVehicleRegNo("TL111");

        CodedValue inCorrectMake = new CodedValue(113L, 12L, "Valid TableId is 105");
        vehicle.setMake(new CodedValue(113L, 12L, "Valid TableId is 105")); // invalid

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(onlineReportErrors.count() == 2);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.type", incorrectType.toString()));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_INVALID_VALUE, "niaObject.make", inCorrectMake.toString()));
    }

    /**
     * Test for adding a vehicle with invalid type and Rego
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithInValidTypeAndRego() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();
        CodedValue incorrectType = new CodedValue(110L, 12L, "Valid TableId is 107");
        vehicle.setType(incorrectType); // invalid

        vehicle.setVehicleRegNo("TL111121212121"); // Invalid

        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(onlineReportErrors.count() == 2);
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.type", incorrectType.toString()));
        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.vehicleRgNo", "TL111121212121"));

    }  
    /**
     * 
     * @105 @api_gateway @vehicle @validation
     */
    @Test
    public void testVehicleWithNullTypeValue() throws OnlineReportException {
        Vehicle vehicle = Vehicle.builder().build();

        CodedValue incorrectType = new CodedValue(107L, null, "null type");
        vehicle.setType(incorrectType); // invalid

        vehicle.setVehicleRegNo("TL111");

        vehicle.setMake(new CodedValue(105L, 12L, "Valid TableId"));

        vehicleValidator.validate(vehicle, onlineReportErrors);

        assertTrue(containsError(AbstractValidator.ERROR_MESSAGE_FOR_BLANK_OR_INVALID_VALUE, "niaObject.type", incorrectType.toString()));
    }
    
    
}
